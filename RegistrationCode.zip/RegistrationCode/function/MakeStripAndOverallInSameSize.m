function MovingimgInfo=MakeStripAndOverallInSameSize(FixedimgInfo,MovingimgInfo,parameter,Path)
    
    moving_x=[];
    moving_y=[];
    max_intensity = 50;
    saveStripCropImgName=strcat(Path,'\',MovingimgInfo.Movingimgfile(1:end-5),'_crop.tiff');
    [~, fileName, ext] = fileparts(saveStripCropImgName);
    Movingimgfile = [fileName, ext];  

    saveShiftMat = strcat(Path,'\Shift.mat');
    if exist(saveStripCropImgName,'file')==2
        MovingimgInfo.Movingimg=imread(saveStripCropImgName);
        MovingimgInfo.Movingimgallpath=saveStripCropImgName;
        MovingimgInfo.Movingimgfile=Movingimgfile;
        disp('Crop Image has been done.');
    elseif exist(saveShiftMat,'file')==2
        load(saveShiftMat);
        fixedImg=FixedimgInfo.Fixedimg;
        movingImg=MovingimgInfo.Movingimg;
        minRow = size(fixedImg,1);
        minCol = size(fixedImg,2);

        movingImg1=uint8(zeros(minRow,minCol));
        if size(fixedImg,1)>size(movingImg,1)
            if size(fixedImg,2)>size(movingImg,2)
                movingImg1(1:size(movingImg,1),1:size(movingImg,2)) = movingImg;
                movingImg=movingImg1;
            else
                movingImg1(1:size(movingImg,1),:) = movingImg(:, 1:minCol);
                movingImgtemp=uint8(zeros(minRow,size(movingImg,2)));
                movingImgtemp(:, 1:minCol)=movingImg1;
                movingImg=movingImgtemp;
            end
        else
            if size(fixedImg,2)>size(movingImg,2)
                movingImg1(:,1:size(movingImg,2)) = movingImg(1:minRow, :);
                movingImgtemp=uint8(zeros(size(movingImg,1),minCol));
                movingImgtemp(1:minRow, :)=movingImg1;
                movingImg=movingImgtemp;
            else
                movingImg1 = movingImg(1:minRow, 1:minCol);
            end
        end

        sum_moving_x=sum(moving_x(:));
        sum_moving_y=sum(moving_y(:));
        movingImg1=uint8(zeros(minRow,minCol));
        if sum_moving_x>0
            if sum_moving_y>0
                movingImg1(1:minRow-sum_moving_y,1:minCol-sum_moving_x)=movingImg(sum_moving_y+1:end,sum_moving_x+1:end);
            else
                movingImg1(abs(sum_moving_y)+1:end,:)=movingImg(1:minRow-abs(sum_moving_y),sum_moving_x+1:sum_moving_x+minCol);
            end
        else
            if sum_moving_y>0
                movingImg1(:,abs(sum_moving_x)+1:end)=movingImg(sum_moving_y+1:sum_moving_y+minRow,1:minCol-abs(sum_moving_x));
            else
                movingImg1(abs(sum_moving_y)+1:end,abs(sum_moving_x)+1:end)=movingImg(1:minRow-abs(sum_moving_y),1:minCol-abs(sum_moving_x));
            end
        end
        MovingimgInfo.Movingimg=movingImg1;
        MovingimgInfo.Movingimgallpath=saveStripCropImgName;
        MovingimgInfo.Movingimgfile=Movingimgfile;
        imwrite(movingImg1,saveStripCropImgName);
        disp('Crop Size has been done.');
    else
        fixedImg=FixedimgInfo.Fixedimg;
        movingImg=MovingimgInfo.Movingimg;
        minRow = size(fixedImg,1);
        minCol = size(fixedImg,2);
        
        % make image in same size
        movingImg1=uint8(zeros(minRow,minCol));
        if size(fixedImg,1)>size(movingImg,1)
            if size(fixedImg,2)>size(movingImg,2)
                movingImg1(1:size(movingImg,1),1:size(movingImg,2)) = movingImg;
                movingImg=movingImg1;
            else
                movingImg1(1:size(movingImg,1),:) = movingImg(:, 1:minCol);
                movingImgtemp=uint8(zeros(minRow,size(movingImg,2)));
                movingImgtemp(:, 1:minCol)=movingImg1;
                movingImg=movingImgtemp;
            end
        else
            if size(fixedImg,2)>size(movingImg,2)
                movingImg1(:,1:size(movingImg,2)) = movingImg(1:minRow, :);
                movingImgtemp=uint8(zeros(size(movingImg,1),minCol));
                movingImgtemp(1:minRow, :)=movingImg1;
                movingImg=movingImgtemp;
            else
                movingImg1 = movingImg(1:minRow, 1:minCol);
            end
        end
        fixedImg_adj  = uint8(mat2gray(fixedImg,[0 max_intensity+10]));
        movingImg1_adj  = uint8(mat2gray(movingImg1,[0 max_intensity]));
        for i=1:parameter.RoughRegisterNum
            f1=figure(2);
            imshowpair(fixedImg_adj,movingImg1_adj);
            [~,position]=getStripImg(fixedImg,parameter.CropImgSize(1),parameter.CropImgSize(2),f1);
            fixed_roi=fixedImg(position(2):position(4),position(1):position(3));
            moving_roi=movingImg1(position(2):position(4),position(1):position(3));
            [moving_x1,moving_y1]=overlop_PhaseCorrelation(fixed_roi,moving_roi);
            if moving_y1==0 && moving_x1==0
                break
            end
            moving_x=[moving_x;moving_x1];
            moving_y=[moving_y;moving_y1];
            sum_moving_x=sum(moving_x(:));
            sum_moving_y=sum(moving_y(:));
            movingImg1=uint8(zeros(minRow,minCol));
            if abs(moving_x1)>size(moving_roi,2) || abs(moving_y1)>size(moving_roi,1)
                continue
            end
            if sum_moving_x>0
                if sum_moving_y>0
                    movingImg1(1:minRow-sum_moving_y,1:minCol-sum_moving_x)=movingImg(sum_moving_y+1:end,sum_moving_x+1:end);
                else
                    movingImg1(abs(sum_moving_y)+1:end,1:minCol-sum_moving_x)=movingImg(1:minRow-abs(sum_moving_y),sum_moving_x+1:minCol);
                end
            else
                if sum_moving_y>0
                    movingImg1(1:minRow-sum_moving_y,abs(sum_moving_x)+1:end)=movingImg(sum_moving_y+1:end,1:minCol-abs(sum_moving_x));
                else
                    movingImg1(abs(sum_moving_y)+1:end,abs(sum_moving_x)+1:end)=movingImg(1:minRow-abs(sum_moving_y),1:minCol-abs(sum_moving_x));
                end
            end
            movingImg1_adj  = uint8(mat2gray(movingImg1,[0 max_intensity]));
        end
        MovingimgInfo.Movingimg=movingImg1;
        MovingimgInfo.Movingimgallpath=saveStripCropImgName;
        MovingimgInfo.Movingimgfile=Movingimgfile;
        imwrite(movingImg1,saveStripCropImgName);
        save(saveShiftMat,'moving_x','moving_y');
    end
    
end



function [StripImgInfo,parameter]=OnlySaveStripInfo(parameter,StripImgInfo,Path)
    saveOnlyStripName=strcat(Path,'\',StripImgInfo.Stripimgfile(1:end-5),'_onlyStrip.tiff');
    [~, fileName, ext] = fileparts(saveOnlyStripName);
    Stripimgfile = [fileName, ext];  
    saveStripIdxInfoName=strcat(Path,'\StripIdxInfo','.mat');
    if strcmp(parameter.channel,'365')
        disp("Channel is 365, skipping further execution.");
    elseif exist(saveOnlyStripName,'file')==2
        StripImgSave=imread(saveOnlyStripName);
        StripImgInfo.Stripimg=StripImgSave;
        StripImgInfo.Stripimgallpath=saveOnlyStripName;
        StripImgInfo.Stripimgfile=Stripimgfile;
        load(saveStripIdxInfoName);
%         'crop_roiPosition_x','first_cropStripNum','add_shift',"Strip_W",'StripInterval_W'
        parameter.first_cropStripNum=first_cropStripNum;
        parameter.crop_roiPosition_x=crop_roiPosition_x;
        parameter.add_shift=add_shift;
        parameter.Strip_W=Strip_W;
        parameter.StripInterval_W=StripInterval_W;
        disp("Only Strip Image has been done.");
    else
        Stripimg = StripImgInfo.Stripimg;
        maxIntensity = 30;
        crop_size_x = parameter.StripCropImgSize(1);
        crop_size_y = parameter.StripCropImgSize(2);
        [imgrows,imgcols]=size(Stripimg);
        
        
        while(1)
            f1=figure(1);
            imshow(Stripimg,[0 maxIntensity]);
            roiPosition=SelectAnyArea(crop_size_x,crop_size_y,imgrows,imgcols,f1);
            roi_img=Stripimg(roiPosition(2):roiPosition(4),roiPosition(1):roiPosition(3));
            meanall = mean(roi_img(:));
            column_counts = sum(roi_img > meanall, 1);
            
            column_counts = column_counts/size(roi_img,1);
            column_counts(column_counts<0.1)=0;
            figure(2);
            plot(column_counts);
            
            index_zeros=find(column_counts<=0);
            diff_index_zeros=diff(index_zeros);
            index_diff=find(diff_index_zeros>1);
            index_diff=[index_diff length(diff_index_zeros)];
            index_diff1=index_zeros(index_diff(1:end));
            index_diff2=index_zeros(index_diff(1:end-1)+1);
            all_indices = [index_diff1, index_diff2];
            crop_flag=input("Inter whether Crop Again(1/0):");
            if crop_flag==1 || length(all_indices)>crop_size_x/1000*2+1
                continue
            else
                break
            end
        end
        
        
        % Sort from smallest to largest
        sorted_indices = sort(all_indices);
        diff_sort_indices = diff(sorted_indices);
        odd_position_elements = diff_sort_indices(1:2:end);
        even_position_elements = diff_sort_indices(2:2:end);
        mean_odd = round(mean(odd_position_elements));
        mean_even = round(mean(even_position_elements));
        flag = 1;
       
        if column_counts(index_diff(1))>column_counts(index_diff(1)+1)
            
            Strip_W=mean_even;
            StripInterval_W=mean_odd;
        else
            
            Strip_W=mean_odd;
            StripInterval_W=mean_even;
        end
        
        first_cropStripNum=input("Inter the First Strip CropImg Correspond OverallImg Strip Num:");
        total_StripNum = parameter.total_StripNum;
        StripImgSave=uint8(zeros(size(Stripimg)));
        add_shift=0;
        crop_roiPosition_x=roiPosition(1);
        if flag==1
            back_start=roiPosition(1)+sorted_indices(1);
            crop_roiPosition_x=back_start;
            front_start=roiPosition(1)+sorted_indices(1)-StripInterval_W;
            for i=first_cropStripNum:total_StripNum
                StripImgSave(:,back_start-add_shift:back_start+Strip_W+add_shift)=Stripimg(:,back_start-add_shift:back_start+Strip_W+add_shift);
                back_start=back_start+Strip_W+StripInterval_W;
            end
            for j=first_cropStripNum-1:-1:1
                StripImgSave(:,front_start-Strip_W-add_shift:front_start+add_shift)=Stripimg(:,front_start-Strip_W-add_shift:front_start+add_shift);
                front_start=front_start-Strip_W-StripInterval_W;
            end
        else
            
            back_start=roiPosition(1)-sorted_indices(1)+StripInterval_W;
            front_start=roiPosition(1)-sorted_indices(1);
            crop_roiPosition_x = front_start-Strip_W;
            for i=first_cropStripNum+1:total_StripNum
                StripImgSave(:,back_start-add_shift:back_start+Strip_W+add_shift)=Stripimg(:,back_start-add_shift:back_start+Strip_W+add_shift);
                back_start=back_start+Strip_W+StripInterval_W;
            end
            for j=first_cropStripNum:-1:1
                StripImgSave(:,front_start-Strip_W-add_shift:front_start+add_shift)=Stripimg(:,front_start-Strip_W-add_shift:front_start+add_shift);
                front_start=front_start-Strip_W-StripInterval_W;
            end
        end
        imwrite(StripImgSave,saveOnlyStripName); 
        StripImgInfo.Stripimg=StripImgSave;
        StripImgInfo.Stripimgallpath=saveOnlyStripName;
        StripImgInfo.Stripimgfile=Stripimgfile;
        parameter.first_cropStripNum=first_cropStripNum;
        parameter.crop_roiPosition_x=crop_roiPosition_x;
        parameter.add_shift=add_shift;
        parameter.Strip_W=Strip_W;
        parameter.StripInterval_W=StripInterval_W;
        save(saveStripIdxInfoName,'crop_roiPosition_x','first_cropStripNum','add_shift',"Strip_W",'StripInterval_W');
    end
end




clc;clear;close all;
addpath(genpath(pwd));
Path = 'D:\lqh\zy\data\扁桃体\Result';
[Fusedimgfile, Fusedimgpath] = uigetfile({'*.tiff', 'Select Fused Image File'}, 'Select Fused Image File', Path);
[Fuseimgfile, Fuseimgpath] = uigetfile({'*.tiff', 'Select Fuse Image File'}, 'Select Fuse Image File', Path);
Fusedimgallpath=strcat(Fusedimgpath,Fusedimgfile);
Fuseimgallpath=strcat(Fuseimgpath,Fuseimgfile);
Fusedimg = imread(Fusedimgallpath);
Fuseimg = imread(Fuseimgallpath);


maskA = Fusedimg > Fuseimg;  
maskB =  ~maskA;  

 
F = uint8(zeros(size(Fusedimg)));


F(maskA)   = Fusedimg(maskA);
F(maskB)   = 0.1*Fusedimg(maskB)+0.9*Fuseimg(maskB);

saveRemoveImgName = strcat(Path,'\',Fusedimgfile(1:end-5),'_fuse.tiff');
imwrite(F,saveRemoveImgName);

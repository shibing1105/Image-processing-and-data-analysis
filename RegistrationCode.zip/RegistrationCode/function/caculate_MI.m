function MI=caculate_MI(roi_fixed_adj,roi_moving_reg)
    % Calculate mutual information
    nbins = 64;
    jointHist = histcounts2(double(roi_fixed_adj(:)), double(roi_moving_reg(:)), nbins, 'Normalization', 'probability');
    jointHist(jointHist==0)=eps; 
    H_joint = -sum(jointHist(:).*log2(jointHist(:)));
    
    H_fixed = -sum(sum(histcounts(double(roi_fixed_adj(:)), nbins, 'Normalization','probability') .* ...
                       log2(histcounts(double(roi_fixed_adj(:)), nbins, 'Normalization','probability')+eps)));
    
    H_moving = -sum(sum(histcounts(double(roi_moving_reg(:)), nbins, 'Normalization','probability') .* ...
                       log2(histcounts(double(roi_moving_reg(:)), nbins, 'Normalization','probability')+eps)));
    
    MI = H_fixed + H_moving - H_joint;
end
function rotated_img = rotateAroundCenter(img, angle_deg, center_point)
    % 围绕指定点旋转图像并保持原始尺寸
    [height, width] = size(img);
    
    % 创建仿射变换矩阵
    angle_rad = deg2rad(angle_deg);
    cos_theta = cos(angle_rad);
    sin_theta = sin(angle_rad);
    
    % 计算变换参数
    tx = center_point(1) * (1 - cos_theta) + center_point(2) * sin_theta;
    ty = center_point(2) * (1 - cos_theta) - center_point(1) * sin_theta;
    
    % 构建变换矩阵
    tform = affine2d([cos_theta, -sin_theta, 0; 
                      sin_theta,  cos_theta, 0; 
                      tx,         ty,         1]);
    
    % 应用变换，保持原始尺寸
    output_view = imref2d([height, width]);
    rotated_img = imwarp(img, tform, 'OutputView', output_view, 'Interpolation', 'bilinear');
end
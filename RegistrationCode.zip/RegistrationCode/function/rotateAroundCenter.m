function rotated_img = rotateAroundCenter(img, angle_deg, center_point)

    % Rotate the image around a specified point while maintaining the original size
    [height, width] = size(img);
    
    % Create an affine transformation matrix
    angle_rad = deg2rad(angle_deg);
    cos_theta = cos(angle_rad);
    sin_theta = sin(angle_rad);
    
    % Calculate transformation parameters
    tx = center_point(1) * (1 - cos_theta) + center_point(2) * sin_theta;
    ty = center_point(2) * (1 - cos_theta) - center_point(1) * sin_theta;
    
    % Construct transformation matrix
    tform = affine2d([cos_theta, -sin_theta, 0; 
                      sin_theta,  cos_theta, 0; 
                      tx,         ty,         1]);
    
    % Apply the transformation and maintain the original size
    output_view = imref2d([height, width]);
    rotated_img = imwarp(img, tform, 'OutputView', output_view, 'Interpolation', 'bilinear');
end
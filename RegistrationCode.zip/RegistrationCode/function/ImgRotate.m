function [FixedimgInfo,MovingimgInfo]=ImgRotate(FixedimgInfo,MovingimgInfo,Path)
    
    saveOnlyfixedName=strcat(Path,'\',FixedimgInfo.Fixedimgfile(1:end-5),'_rotate.tiff');
    saveOnlymovingName=strcat(Path,'\',MovingimgInfo.Movingimgfile(1:end-5),'_rotate.tiff');
    [~, fileName, ext] = fileparts(saveOnlyfixedName);
    Fixedimgfile = [fileName, ext];
    [~, fileName, ext] = fileparts(saveOnlymovingName);
    Movingimgfile = [fileName, ext];
    if exist(saveOnlyfixedName,'file')==2
        FixedImgSave=imread(saveOnlyfixedName);
        FixedimgInfo.Fixedimg=FixedImgSave;
        FixedimgInfo.Fixedimgallpath=saveOnlyfixedName;
        FixedimgInfo.Fixedimgfile=Fixedimgfile;
    elseif exist(saveOnlymovingName,'file')==2
        MovingImgSave=imread(saveOnlymovingName);
        MovingimgInfo.Movingimg=MovingImgSave;
        MovingimgInfo.Movingimgallpath=saveOnlymovingName;
        MovingimgInfo.Movingimgfile=Movingimgfile;
    else
        fixedImg = FixedimgInfo.Fixedimg;
        movingImg=MovingimgInfo.Movingimg;
        fixedImg=singleImgRotate(fixedImg);
        movingImg=singleImgRotate(movingImg);

        imwrite(fixedImg,saveOnlyfixedName); 
        FixedimgInfo.Fixedimg=fixedImg;
        FixedimgInfo.Fixedimgallpath=saveOnlyfixedName;
        FixedimgInfo.Fixedimgfile=Fixedimgfile;
        imwrite(movingImg,saveOnlymovingName); 
        MovingimgInfo.Movingimg=movingImg;
        MovingimgInfo.Movingimgallpath=saveOnlymovingName;
        MovingimgInfo.Movingimgfile=Movingimgfile;
    end
end

clc;clear;close all;
MatFilepath='D:\lqh\zy\driftAndcrosstalk\Drift\Drift_list_708.mat';
loadedData = load(MatFilepath);
variableNames = fieldnames(loadedData);
firstVarName = variableNames{1};
dataValue=loadedData.(firstVarName);
% drift
headers = {'StartCoord_x(pixel)', 'StartCoord_y(pixel)', 'ROISize', ...
           'drift_x(pixel)', 'drift_y(pixel)', 'methordflag', ...
           'drift(pixel)', 'drift(um)'}; 
dataValue(:,end+1)=sqrt(dataValue(:,5).^2+dataValue(:,4).^2);
pixel_size=0.553;
dataValue(:,end+1)=dataValue(:,end)*pixel_size;

% % crosstalk
% headers = {'StartCoord_x(pixel)', 'StartCoord_y(pixel)', 'ROISize', 'Raw_Intensity', 'crosstalk_Intensity', 'Crosstalk_ratio_Raw'};  % 表头名称
% dataValue(:,end+1)=dataValue(:,5)./dataValue(:,4);

% % AntigenAttenuation
% headers = {'StartCoord_x(pixel)', 'StartCoord_y(pixel)', 'ROISize', 'drift_x(pixel)', 'drift_y(pixel)', 'area_overall', 'area_strip', 'Intensity_overall', 'Intensity_strip'};  % 表头名称

dataTable = array2table(dataValue, 'VariableNames', headers);


csvName=strcat(MatFilepath(1:end-4),'.csv');
if istable(dataTable)
    writetable(dataTable, csvName); 
else
    writematrix(dataTable, csvName); 
end
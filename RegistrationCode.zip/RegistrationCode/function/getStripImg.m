function [imgResult,roiPosition]=getStripImg(img,fixedWidth,fixedHeight,f1)

    
    [imgrows,imgcols]=size(img);
    roiPosition=SelectAnyArea(fixedWidth,fixedHeight,imgrows,imgcols,f1);
    imgResult=zeros(size(img,1),size(img,2));
    imgResult=uint8(imgResult);
    imgResult(:,roiPosition(1):roiPosition(3))=img(:,roiPosition(1):roiPosition(3));
end
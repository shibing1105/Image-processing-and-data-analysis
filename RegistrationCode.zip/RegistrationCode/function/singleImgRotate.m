function img=singleImgRotate(inputimg)
    maxIntensity = 30;
    crop_size_x = 800;
    crop_size_y = 2000;
    [imgrows,imgcols]=size(inputimg);
    f1=figure(1);
    imshow(inputimg,[0 maxIntensity]);
    inputFlag=input("Inter the flag to charge whether rotate(1/0):");
    if inputFlag==1
        roiPosition=SelectAnyArea(crop_size_x,crop_size_y,imgrows,imgcols,f1);
        roi = inputimg(roiPosition(2):roiPosition(4),roiPosition(1):roiPosition(3));  
        level = graythresh(roi);
        binary_roi = imbinarize(roi, level);
        se=strel('disk',11);
        dilated_img = imdilate(binary_roi, se);
        stats = regionprops(dilated_img, 'Orientation', 'Centroid', 'Area');
        [max_area, max_idx] = max([stats.Area]);
        tilt_angle = stats(max_idx).Orientation;
        rotation_center = stats(max_idx).Centroid;
        if tilt_angle>0
		    rotation_angle = 90-tilt_angle;
	    else
		    rotation_angle = -tilt_angle-90;
	    end
	    global_rotation_center = [roiPosition(1) + rotation_center(1) - 1, ...
                          roiPosition(2) + rotation_center(2) - 1];
	    img = rotateAroundCenter(inputimg, rotation_angle, global_rotation_center);
    else
	    img=inputimg;
    end
		
end
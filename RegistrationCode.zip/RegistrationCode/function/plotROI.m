function plotROI(f_num,maxIntensity,flag,roi_fixed,roi_moving,fixedPoints,movingPoints)
    figure(f_num);  
        
    if flag==1
        subplot(1,3,1); 
        cla;   
        imshow(roi_fixed, [0 maxIntensity]);
        title('Fixed ROI');
        
        subplot(1,3,2);  
        cla;   
        imshow(roi_moving, [0 maxIntensity]);
        title('Moving ROI (NoRegistered)');
        
        subplot(1,3,3);  
        cla;   
        imshowpair(roi_fixed, roi_moving);
        title('Overlay');
        drawnow;
    else
        subplot(1,2,1);
        cla;   
        imshow(roi_fixed, [0 maxIntensity]);
        hold on; plot(fixedPoints(:,1), fixedPoints(:,2), 'r.', 'MarkerSize', 10);
        title('Fixed ROI');
        
        subplot(1,2,2);  
        cla;   
        imshow(roi_moving, [0 maxIntensity]);
        hold on; plot(movingPoints(:,1), movingPoints(:,2), 'r.', 'MarkerSize', 10);
        title('Moving ROI (NoRegistered)');
        
        drawnow;
    end

end

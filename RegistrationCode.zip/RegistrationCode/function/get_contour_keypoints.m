function keypoints = get_contour_keypoints(img)
    vals = img(:);
    
   
    valUp_90 = vals > prctile(vals, 95);
    logical_matrix = reshape(valUp_90, size(img));
    [y, x] = find(logical_matrix);
    candidatePts = [x, y];  % N x 2
    keypoints=candidatePts;
end
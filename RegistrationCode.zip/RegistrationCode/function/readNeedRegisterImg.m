function [FixedimgInfo,MovingimgInfo]=readNeedRegisterImg(Path)
    [Fixedimgfile, Fixedimgpath] = uigetfile({'*.tif*', 'Select Fixed Image File'}, 'Select Fixed Image File', Path);
    [Movingimgfile, Movingimgpath] = uigetfile({'*.tif*', 'Select Moving Image File'}, 'Select Moving Image File', Path);
    Fixedimgallpath=strcat(Fixedimgpath,Fixedimgfile);
    Movingimgallpath=strcat(Movingimgpath,Movingimgfile);
    Fixedimg = imread(Fixedimgallpath);
    Movingimg = imread(Movingimgallpath);
    FixedimgInfo.Fixedimgfile = Fixedimgfile;
    FixedimgInfo.Fixedimgallpath = Fixedimgallpath;
    FixedimgInfo.Fixedimg = Fixedimg;
    MovingimgInfo.Movingimgfile = Movingimgfile;
    MovingimgInfo.Movingimgallpath = Movingimgallpath;
    MovingimgInfo.Movingimg = Movingimg;
end
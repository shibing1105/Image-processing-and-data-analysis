function [dx,dy]=overlop_PhaseCorrelation(overlop_roi1,overlop_roi2)
%     F1 = fft2(double(overlop_roi1));
%     F2 = fft2(double(overlop_roi2));
%     S = F2 .* conj(F1);
%     R = S ./ (abs(S) + eps);  
%     P = abs(ifft2(R));
%     [ypeak, xpeak] = find(P == max(P(:)), 1);
%     [rows, cols] = size(overlop_roi1);
%     dx = mod(xpeak - 1 + floor(cols/2), cols) - floor(cols/2);
%     dy = mod(ypeak - 1 + floor(rows/2), rows) - floor(rows/2);
%     fprintf('Translation offset: dx = %.2f, dy = %.2f\n', dx, dy);
   
    corr_output = normxcorr2(overlop_roi1, overlop_roi2);
    [max_c, imax] = max(abs(corr_output(:)));
    [ypeak, xpeak] = ind2sub(size(corr_output), imax(1));
    dy = ypeak - size(overlop_roi1,1);
    dx = xpeak - size(overlop_roi1,2);
    
    fprintf('overlop_PhaseCorrelation translation offset: dx = %.2f, dy = %.2f\n', dx, dy);
end
clc;clear;close all;
addpath(genpath(pwd));
Path = 'D:\lqh\zy\data\扁桃体20250909\EveryChannel Result';
[Stripimgfile, Stripimgpath] = uigetfile({'*.tiff', 'Select Strip Image File'}, 'Select Strip Image File', Path);
Stripimgallpath=strcat(Stripimgpath,Stripimgfile);
Stripimg = imread(Stripimgallpath);
[imgrows,imgcols]=size(Stripimg);
OverallImgList=dir(fullfile(Path,'\*gray.tiff'));
[StripNumInfoMatfile, StripNumInfoMatpath] = uigetfile({'*.mat', 'Select Strip Info File'}, 'Select Strip Info File', Path);
StripNumInfoMat=strcat(StripNumInfoMatpath,StripNumInfoMatfile);
load(StripNumInfoMat);

CombineImg=uint8(zeros(size(Stripimg)));
add_shift=50;
for i = 1:size(OverallImgList,1)
    disp(OverallImgList(i).name);
    CurrentStripIndex=[];
    while(1)
        StripNum=input("Please inter the channel correspond strip Num:");
        CurrentStripIndex=[CurrentStripIndex;StripNum];
        flag=input("Please choose continue or break(1/0):");
        if flag==0
            break
        end
    end
    OverallImg=imread(fullfile(OverallImgList(i).folder,'\',OverallImgList(i).name));
    for j=1:size(CurrentStripIndex,1)
        curretStripNum=CurrentStripIndex(j);
        if curretStripNum>first_cropStripNum
            diff_StripNum=curretStripNum-first_cropStripNum;
            currentStripFirst_x=crop_roiPosition_x+diff_StripNum*Strip_W+diff_StripNum*StripInterval_W;
        else
            diff_StripNum=first_cropStripNum-curretStripNum;
            currentStripFirst_x=crop_roiPosition_x-diff_StripNum*Strip_W-diff_StripNum*StripInterval_W;
        end
        CombineImg(:,currentStripFirst_x-add_shift:currentStripFirst_x+Strip_W+add_shift)=OverallImg(:, ...
            currentStripFirst_x-add_shift:currentStripFirst_x+Strip_W+add_shift);
    end
end
saveCombineImgName=strcat(Path,'\CombineImg.tiff');
imwrite(CombineImg,saveCombineImgName);

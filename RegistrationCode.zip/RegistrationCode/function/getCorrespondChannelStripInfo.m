function [StripImgInfo,parameter]=getCorrespondChannelStripInfo(StripImgInfo,parameter,Path)
    NeedStripNum=parameter.StripNum;
    saveStripName=strcat(Path,'\',StripImgInfo.Stripimgfile(1:end-5),'_',parameter.channel,'.tiff');
    [~, fileName, ext] = fileparts(saveStripName);
    Stripimgfile = [fileName, ext];  
    if strcmp(parameter.channel, '365')
        disp('Channel is 365, skipping further execution.');
    elseif exist(saveStripName,'file')==2
        StripImgSave=imread(saveStripName);
        StripImgInfo.Stripimg=StripImgSave;
        StripImgInfo.Stripimgallpath=saveStripName;
        StripImgInfo.Stripimgfile=Stripimgfile;
        disp('Correspond Channel Strip has benen done.');
    else
        Stripimg = StripImgInfo.Stripimg;
        StripImgSave=uint8(zeros(size(Stripimg)));
        for i=1:length(NeedStripNum)
            curretStripNum=NeedStripNum(i);
            if curretStripNum>parameter.first_cropStripNum
                diff_StripNum=curretStripNum-parameter.first_cropStripNum;
                currentStripFirst_x=parameter.crop_roiPosition_x+diff_StripNum*parameter.Strip_W+diff_StripNum*parameter.StripInterval_W;
            else
                diff_StripNum=parameter.first_cropStripNum-curretStripNum;
                currentStripFirst_x=parameter.crop_roiPosition_x-diff_StripNum*parameter.Strip_W-diff_StripNum*parameter.StripInterval_W;
            end
            StripImgSave(:,currentStripFirst_x-parameter.add_shift:currentStripFirst_x+parameter.add_shift+parameter.Strip_W)=Stripimg(:,currentStripFirst_x-parameter.add_shift:currentStripFirst_x+parameter.add_shift+parameter.Strip_W);
        end
        StripImgInfo.Stripimgallpath=saveStripName;
        StripImgInfo.Stripimgfile=Stripimgfile;
        StripImgInfo.Stripimg=StripImgSave;
        imwrite(StripImgSave,saveStripName);
    end
end
function keypoints = get_contour_keypoints_enhanced(edgeImg,raw_roi)
  
    [y, x] = find(edgeImg > 0);
    candidatePts = [x, y];  % N x 2
    maskroi=zeros(size(edgeImg));
    maskroi(edgeImg)=raw_roi(edgeImg);
  
    vals = maskroi(maskroi > 0);
    
    strongMask = vals > prctile(vals, 90);
    candidatePts = candidatePts(strongMask, :);
    keypoints=candidatePts;
end


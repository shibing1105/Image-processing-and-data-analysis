function processed_edges = postprocess_edges(edge_map)
    
    se_dilate = strel('disk', 3);  
    dilated_edges = imdilate(edge_map, se_dilate);
    
    filled_edges = imfill(dilated_edges, 'holes');
    
   
    se_erode = strel('disk', 2);  
    processed_edges = imerode(filled_edges, se_erode);

end
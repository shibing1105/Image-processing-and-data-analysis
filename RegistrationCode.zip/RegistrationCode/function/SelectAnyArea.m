function roiPosition=SelectAnyArea(fixedWidth,fixedHeight,imgcols,imgrows,figure_p)
     
    if isempty(findobj('Type', 'Figure'))
        figure; 
        warning('No active graphics window was found, a new window has been automatically created');
    end
    
    if isempty(imgcols) || isempty(imgrows)
        initialX = 0;
        initialY = 0;
    else
        initialX = (imgcols - fixedWidth)/2;
        initialY = (imgrows - fixedHeight)/2;
    end
    
    
    ax = findobj(figure_p, 'Type', 'axes'); 
    roi = images.roi.Rectangle('Parent', ax, 'Position', [initialY initialX fixedWidth fixedHeight], 'Color', [1 1 1]);

    disp('Adjust the position of the rectangle, then double-click the rectangle to confirm.');
    wait(roi);

   
    position = roi.Position;

    
    x = round(position(1));
    y = round(position(2));
    width = round(position(3));
    height = round(position(4));
    topx=x;
    topy=y;
    downx=x+width;
    downy=y+height;
    roiPosition = [topx,topy,downx,downy];
%     croppedImg = imcrop(flipped_img, [x y width height]);
end
function [rows, cols] = getRandomPixels(image, numPoints)
    binaryImage = imbinarize(image);
    signalIndices = find(binaryImage);
   
    totalSignalPixels = length(signalIndices);
    if numPoints > totalSignalPixels
        numPoints = totalSignalPixels;
        fprintf('警告：点数超过信号区域总像素，将返回所有信号像素点。\n');
    end
    selectedIndices = signalIndices(randperm(totalSignalPixels, numPoints));
    
    [rows, cols] = ind2sub(size(binaryImage), selectedIndices);
%     [height, width] = size(image);
%    
%     totalPixels = height * width;
%     if numPoints > totalPixels
%         numPoints = totalPixels;
%         fprintf('警告：点数超过图像总像素，将返回所有像素点。\n');
%     end
%     
%     randomIndices = randperm(totalPixels, numPoints);
%     
%     [rows, cols]= ind2sub([height, width], randomIndices);

end
function [rows, cols] = getRandomPixels(image, numPoints)
    binaryImage = imbinarize(image);
    signalIndices = find(binaryImage);
   
    totalSignalPixels = length(signalIndices);
    if numPoints > totalSignalPixels
        numPoints = totalSignalPixels;
        fprintf('Warning: If the number of points exceeds the total pixels in the signal area, all signal pixels will be returned.\n');
    end
    selectedIndices = signalIndices(randperm(totalSignalPixels, numPoints));
    
    [rows, cols] = ind2sub(size(binaryImage), selectedIndices);
%     [height, width] = size(image);
%    
%     totalPixels = height * width;
%     if numPoints > totalPixels
%         numPoints = totalPixels;
%         fprintf('Warning: If the number of points exceeds the total pixels in the signal area, all signal pixels will be returned.\n');
%     end
%     
%     randomIndices = randperm(totalPixels, numPoints);
%     
%     [rows, cols]= ind2sub([height, width], randomIndices);

end
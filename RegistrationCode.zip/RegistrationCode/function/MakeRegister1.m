function movingReg=MakeRegister1(FixedimgInfo,MovingimgInfo,parameter,Path)
    saveMovingRegisterName=strcat(Path,'\',MovingimgInfo.Movingimgfile(1:end-5), '_register.tiff');
    maxIntensity=50;
    RSize=50;
    sigma=parameter.gauss_sigma;
    saveT_globalMatName=strcat(Path,'\T_global.mat');
    featureNum=4;
    if exist(saveMovingRegisterName,'file')==2
        disp("Register has been done!");
        movingReg=imread(saveMovingRegisterName);
    elseif exist(saveT_globalMatName,'file')==2
        disp('The Geometric Transformation has been done.');
        T_global=load(saveT_globalMatName);
        T_global=T_global.T_global;
        fixedImg=FixedimgInfo.Fixedimg;
        movingImg=MovingimgInfo.Movingimg;
        Rfixed = imref2d(size(fixedImg));
        movingReg = imwarp(movingImg, T_global, 'OutputView', Rfixed);
        imwrite(uint8(movingReg),saveMovingRegisterName);
    else
        fixedImg=FixedimgInfo.Fixedimg;
        movingImg=MovingimgInfo.Movingimg;
        % find feature in block size
        interval_distance_x = parameter.block_interval_distance(1);
        interval_distance_y = parameter.block_interval_distance(2);
        blocksize_x=parameter.blocksize(1);
        blocksize_y=parameter.blocksize(2);
        % single Strip block num
        blocknum_x = ceil((parameter.Strip_W+parameter.StripInterval_W*0.7)/interval_distance_x);
        blocknum_y = ceil(round(size(fixedImg,1)*0.7)/interval_distance_y);
        NeedStripNum=parameter.StripNum;
        % save global points
        movingPtsAll = [];
        fixedPtsAll  = [];
        for i=1:length(NeedStripNum)
            curretStripNum=NeedStripNum(i);
            if curretStripNum>parameter.first_cropStripNum
                diff_StripNum=curretStripNum-parameter.first_cropStripNum;
                currentStripFirst_x=parameter.crop_roiPosition_x+diff_StripNum*parameter.Strip_W+diff_StripNum*parameter.StripInterval_W;
            else
                diff_StripNum=parameter.first_cropStripNum-curretStripNum;
                currentStripFirst_x=parameter.crop_roiPosition_x-diff_StripNum*parameter.Strip_W-diff_StripNum*parameter.StripInterval_W;
            end
            start_y=round(size(fixedImg,1)*0.09);
            start_x=round(currentStripFirst_x-parameter.StripInterval_W/2);
            for m = 1:blocknum_y
                first_y = round(start_y+(m-1) * interval_distance_y);
                for n = 1:blocknum_x
                    first_x = round(start_x + (n-1)*interval_distance_x);
                    roi_fixed=fixedImg(first_y:first_y+blocksize_y,first_x:first_x+blocksize_x);
                    roi_moving=movingImg(first_y:first_y+blocksize_y,first_x:first_x+blocksize_x);
                    roi_fixed_mask=uint8(roi_fixed>0);
                    roi_moving_mask=uint8(roi_moving>0);
                    roi_fixed = roi_fixed.*roi_moving_mask;
                    roi_moving = roi_moving.*roi_fixed_mask;
                    % add phase correlation
                    [moving_x1,moving_y1]=overlop_PhaseCorrelation(roi_fixed,roi_moving);
%                     plotROI(1,maxIntensity,1,roi_fixed,roi_moving);
                    if abs(moving_y1)>100 || abs(moving_x1)>100
                        continue
                    end
%                     plotROI(1,maxIntensity,1,roi_fixed,roi_moving);
                    roi_moving_correct=movingImg(first_y+moving_y1:first_y+blocksize_y+moving_y1,first_x+moving_x1:first_x+blocksize_x+moving_x1);
                    figure(2);
                    imshowpair(roi_fixed,roi_moving_correct);
                    MI=caculate_MI(roi_fixed,roi_moving_correct);
                    if MI>0.09
                        [rows, cols] = getRandomPixels(roi_fixed, 10);
                        cols_m=cols+moving_x1;
                        rows_m=rows+moving_y1;
                        Moving_global = [first_x + cols_m, first_y + rows_m];
                        Fixed_global = [first_x + cols, first_y + rows];
     
                        movingPtsAll = [movingPtsAll; Moving_global];
                        fixedPtsAll  = [fixedPtsAll; Fixed_global];

                    else

                        fixedPoints = get_contour_keypoints(roi_fixed);
                        
                        if abs(moving_y1)<10 && abs(moving_x1)<10
                            movingPoints = get_contour_keypoints(roi_moving_correct);
                        else
                            movingPoints = fixedPoints;
                        end
                        matchedFixed = [];
                        matchedMoving = [];
                        for k=1:featureNum
                            [matchedFixed1,matchedMoving1]=MatchPoint(roi_fixed,roi_moving_correct,fixedPoints,movingPoints,k,RSize);
                            matchedFixed = [matchedFixed;matchedFixed1];
                            matchedMoving = [matchedMoving;matchedMoving1];
                        end
                       
                        [matchedFixed, ia] = unique(matchedFixed, 'rows', 'stable');
                        matchedMoving = matchedMoving(ia, :);
                        if size(matchedMoving,1)<4
                            continue
                        end
                        
                        try
                            [tform, inlierIdx] = estimateGeometricTransform2D(matchedMoving, matchedFixed, ...
                               'rigid', 'MaxDistance', 2);
                            matchedFixed  = matchedFixed(inlierIdx, :);
                            matchedMoving = matchedMoving(inlierIdx, :);
                        catch ME
                            [idy,idx]=find(roi_fixed==max(roi_fixed(:)));
                            matchedFixed=[idx idy];
                            matchedMoving=[idx idy];
                            if roi_moving_correct(idy,idx)>prctile(roi_moving_correct(:), 95)
                                matchedMoving(:,1)=matchedMoving(:,1)+moving_x1;
                                matchedMoving(:,2)=matchedMoving(:,2)+moving_y1;
                                Moving_global = [first_x + matchedMoving(:,1), first_y + matchedMoving(:,2)];
                                Fixed_global = [first_x + matchedFixed(:,1), first_y + matchedFixed(:,2)];
                                
                                movingPtsAll = [movingPtsAll; Moving_global];
                                fixedPtsAll  = [fixedPtsAll; Fixed_global];
                            end
                            if contains(ME.message, 'Could not find enough inliers')
                                disp('跳过当前配准：无法找到足够的内点。');
                                continue;
                            else
                                rethrow(ME);
                            end
                        end
                        if ~isempty(matchedFixed) || size(matchedMoving,1)>3
                            tform_local = estimateGeometricTransform2D(...
                            matchedMoving, matchedFixed,'similarity', ...
                            'MaxNumTrials', 2000, 'Confidence', 99);
                            movingReg1 = imwarp(roi_moving_correct, tform_local, 'OutputView', imref2d(size(roi_fixed)));
                            
                        end
                        
                        matchedMoving(:,1)=matchedMoving(:,1)+moving_x1;
                        matchedMoving(:,2)=matchedMoving(:,2)+moving_y1;
                        Moving_global = [first_x + matchedMoving(:,1), first_y + matchedMoving(:,2)];
                        Fixed_global = [first_x + matchedFixed(:,1), first_y + matchedFixed(:,2)];
     
                        movingPtsAll = [movingPtsAll; Moving_global];
                        fixedPtsAll  = [fixedPtsAll; Fixed_global];
                    end
                end
            end
        end
        [fixedPtsAll, ia] = unique(fixedPtsAll, 'rows', 'stable');
        movingPtsAll = movingPtsAll(ia, :);
        [T_global, inlierIdx] = estimateGeometricTransform2D( ...
            movingPtsAll, fixedPtsAll, 'affine', ...
            'MaxNumTrials',5000,'Confidence',99.9,'MaxDistance',5);
        
        Rfixed = imref2d(size(fixedImg));
        movingReg = imwarp(movingImg, T_global, 'OutputView', Rfixed);
        imwrite(uint8(movingReg),saveMovingRegisterName);
        save(saveT_globalMatName,'T_global');
    end

end
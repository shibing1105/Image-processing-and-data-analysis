function [matchedFixed,matchedMoving]=MatchPoint(roi_fixed,roi_moving,fixedPoints,movingPoints,flag,RSize)
    if flag==1
        fixedPoints1 =  KAZEPoints(fixedPoints); 
        movingPoints1 =  KAZEPoints(movingPoints); 
    elseif flag==2
        fixedPoints1 =  SIFTPoints(fixedPoints); 
        movingPoints1 =  SIFTPoints(movingPoints); 
    elseif flag==3
        fixedPoints1 =  cornerPoints(fixedPoints); 
        movingPoints1 =  cornerPoints(movingPoints); 
    elseif flag==4
        fixedPoints1 =  BRISKPoints(fixedPoints); 
        movingPoints1 =  BRISKPoints(movingPoints); 
    end
    
    
    [fixedFeatures, fixedPoints] = extractFeatures(roi_fixed, fixedPoints1);
    [movingFeatures, movingPoints] = extractFeatures(roi_moving, movingPoints1);
    
    [indexPairs, matchMetric] = matchFeatures(fixedFeatures, movingFeatures, 'MaxRatio', 0.6,'Unique', true);
    matchedFixed = fixedPoints(indexPairs(:,1), :);
    matchedMoving = movingPoints(indexPairs(:,2), :);
    matchedFixed=matchedFixed.Location;
    matchedMoving=matchedMoving.Location;
    
    
    [matchedFixed,matchedMoving]=filterMatchbyR(RSize,matchedFixed,matchedMoving,matchMetric);

end
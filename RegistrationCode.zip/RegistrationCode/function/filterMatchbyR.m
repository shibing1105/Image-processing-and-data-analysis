function [uniqueFixed,uniqueMoving]=filterMatchbyR(RSzie,matchFixed,matchMoving,matchMetris)

    vals = matchMetris(matchMetris > 0);
    strongMask = vals > prctile(vals, 50);

    matchMetris1=matchMetris(strongMask);
    matchFixed1=matchFixed(strongMask,:);
    matchMoving1=matchMoving(strongMask,:);
    uniqueFixed  = [];
    uniqueMoving = [];
    id_x_list=[];
    for i = 1:size(matchMetris1,1)
        fpt = matchFixed1(i,:);
        
        d = sqrt(sum((matchFixed1 - fpt).^2,2));
        idx = find(d < RSzie);
        
        if length(idx) > 1
            [~,bestIdx] = min(matchMetris1(idx));  
            idx = idx(bestIdx);
        end
        

        if ~ismember(idx, uniqueFixed) && ~ismember(idx, id_x_list)
            id_x_list=[id_x_list;idx];
            uniqueFixed  = [uniqueFixed; matchFixed1(idx,:)];
            uniqueMoving = [uniqueMoving; matchMoving1(idx,:)];
        end
    end
end
function movingReg=MakeRegister(FixedimgInfo,MovingimgInfo,parameter,Path)
    saveMovingRegisterName=strcat(Path,'\',MovingimgInfo.Movingimgfile(1:end-5), '_register.tiff');
    maxIntensity=50;
    RSize=50;
    sigma=parameter.gauss_sigma;
    saveT_globalMatName=strcat(Path,'\T_global.mat');
    featureNum=4;
    if exist(saveMovingRegisterName,'file')==2
        disp("Register has been done!");
        movingReg=imread(saveMovingRegisterName);
    elseif exist(saveT_globalMatName,'file')==2
        disp('The Geometric Transformation has been done.');
        T_global=load(saveT_globalMatName);
        T_global=T_global.T_global;
        fixedImg=FixedimgInfo.Fixedimg;
        movingImg=MovingimgInfo.Movingimg;
      
        Rfixed = imref2d(size(fixedImg));
        movingReg = imwarp(movingImg, T_global, 'OutputView', Rfixed);
        imwrite(uint8(movingReg),saveMovingRegisterName);
    else
        fixedImg=FixedimgInfo.Fixedimg;
        movingImg=MovingimgInfo.Movingimg;
        % find feature in block size
        interval_distance_x = parameter.block_interval_distance(1);
        interval_distance_y = parameter.block_interval_distance(2);
        blocksize_x=parameter.blocksize(1);
        blocksize_y=parameter.blocksize(2);
        % single Strip block num
        blocknum_x = ceil((parameter.Strip_W+parameter.StripInterval_W*0.8)/interval_distance_x);
        blocknum_y = ceil(round(size(fixedImg,1)*0.7)/interval_distance_y);
        NeedStripNum=parameter.StripNum;
        
        movingPtsAll = [];
        fixedPtsAll  = [];
        for i=1:length(NeedStripNum)
            curretStripNum=NeedStripNum(i);
            if curretStripNum>parameter.first_cropStripNum
                diff_StripNum=curretStripNum-parameter.first_cropStripNum;
                currentStripFirst_x=parameter.crop_roiPosition_x+diff_StripNum*parameter.Strip_W+diff_StripNum*parameter.StripInterval_W;
            else
                diff_StripNum=parameter.first_cropStripNum-curretStripNum;
                currentStripFirst_x=parameter.crop_roiPosition_x-diff_StripNum*parameter.Strip_W-diff_StripNum*parameter.StripInterval_W;
            end
            start_y=round(size(fixedImg,1)*0.15);
            start_x=round(currentStripFirst_x-parameter.StripInterval_W/2);
            for m = 1:blocknum_y
                first_y = round(start_y+(m-1) * interval_distance_y);
                for n = 1:blocknum_x
                    first_x = round(start_x + (n-1)*interval_distance_x);
                    roi_fixed=fixedImg(first_y:first_y+blocksize_y,first_x:first_x+blocksize_x);
                    roi_moving=movingImg(first_y:first_y+blocksize_y,first_x:first_x+blocksize_x);
                    % Over 80% of the rough matching has been completed
                    roi_fixed_mask=uint8(roi_fixed>0);
                    roi_moving_mask=uint8(roi_moving>0);
                    roi_fixed = roi_fixed.*roi_moving_mask;
                    roi_moving = roi_moving.*roi_fixed_mask;
%                     plotROI(1,maxIntensity,1,roi_fixed,roi_moving);
                    % Step 1: Edge Detection and Contour Extraction
                    
                    roi_fixed_g=imgaussfilt(roi_fixed, sigma);
                    roi_moving_g=imgaussfilt(roi_moving, sigma);
%                     plotROI(2,maxIntensity,1,roi_fixed_g,roi_moving_g);
                    roi_fixedEdges = edge(roi_fixed_g, 'Canny', [0.1 0.2]);
                    roi_movingEdges = edge(roi_moving_g, 'Canny', [0.1 0.2]);
                    roi_fixedEdges = postprocess_edges(roi_fixedEdges);
                    roi_movingEdges = postprocess_edges(roi_movingEdges);
%                     plotROI(3,1,1,roi_fixedEdges,roi_movingEdges);
                    
                    % Step 2: Extract feature points from the edges
                    fixedPoints = get_contour_keypoints_enhanced(roi_fixedEdges,roi_fixed);
                    movingPoints = get_contour_keypoints_enhanced(roi_movingEdges,roi_moving);
            
%                     plotROI(4,maxIntensity,0,roi_fixed,roi_moving,fixedPoints,movingPoints);
                    matchedFixed = [];
                    matchedMoving = [];
                    for k=1:featureNum
                        [matchedFixed1,matchedMoving1]=MatchPoint(roi_fixed,roi_moving,fixedPoints,movingPoints,k,RSize);
                        matchedFixed = [matchedFixed;matchedFixed1];
                        matchedMoving = [matchedMoving;matchedMoving1];
                    end
                   
                    [matchedFixed, ia] = unique(matchedFixed, 'rows', 'stable');
                    matchedMoving = matchedMoving(ia, :);
%                     [matchedFixed1,matchedMoving1]=MatchPoint(roi_fixed,roi_moving,fixedPoints,movingPoints,1,RSize);
%                     [matchedFixed2,matchedMoving2]=MatchPoint(roi_fixed,roi_moving,fixedPoints,movingPoints,0,RSize);
%                     matchedFixed = [matchedFixed1;matchedFixed2];
%                     matchedMoving = [matchedMoving1;matchedMoving2];
                    if size(matchedMoving,1)<4
                        continue
                    end
                    try
%                     plotROI(6,maxIntensity,0,roi_fixed,roi_moving,matchedFixed,matchedMoving);
                        [tform, inlierIdx] = estimateGeometricTransform2D(matchedMoving, matchedFixed, ...
                           'rigid', 'MaxDistance', 50);
                        matchedFixed  = matchedFixed(inlierIdx, :);
                        matchedMoving = matchedMoving(inlierIdx, :);
                    catch ME
                        
                        if contains(ME.message, 'Could not find enough inliers')
                            disp('跳过当前配准：无法找到足够的内点。');
                            continue;
                        else
                           
                            rethrow(ME);
                        end
                    end
                    if isempty(matchedFixed) || size(matchedMoving,1)<3
                        continue
                    end
                    tform_local = estimateGeometricTransform2D(...
                        matchedMoving, matchedFixed,'similarity', ...
                        'MaxNumTrials', 2000, 'Confidence', 99);
                    
                    T = tform_local.T;   
                    a = T(1,1); b = T(1,2);
                    c = T(2,1); d = T(2,2);
                    tx = T(3,1); ty = T(3,2);
                    
                    s = sqrt(a^2 + c^2);
                    theta = atan2(c, a) * 180/pi;   
                    if abs(theta)>10
                        continue
                    end

                    movingReg1 = imwarp(roi_moving, tform_local, 'OutputView', imref2d(size(roi_fixed)));

                    figure(7);
                    imshowpair(roi_fixed,movingReg1);
                    Moving_global = [first_x + matchedMoving(:,1), first_y + matchedMoving(:,2)];
                    Fixed_global = [first_x + matchedFixed(:,1), first_y + matchedFixed(:,2)];
                    % From the local to the global
                    movingPtsAll = [movingPtsAll; Moving_global];
                    fixedPtsAll  = [fixedPtsAll; Fixed_global];
                end
            end
        end
        [fixedPtsAll, ia] = unique(fixedPtsAll, 'rows', 'stable');
        movingPtsAll = movingPtsAll(ia, :);
        [T_global, inlierIdx] = estimateGeometricTransform2D( ...
            movingPtsAll, fixedPtsAll, 'similarity', ...
            'MaxNumTrials',5000,'Confidence',99.9,'MaxDistance',15);
        % Register the moving image to the fixed image
        Rfixed = imref2d(size(fixedImg));
        movingReg = imwarp(movingImg, T_global, 'OutputView', Rfixed);
        imwrite(uint8(movingReg),saveMovingRegisterName);
        save(saveT_globalMatName,'T_global');
    end

end
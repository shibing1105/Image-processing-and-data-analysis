%%
% 1、choose img
% 2、get correspond strip img
% 3、make img in same size
% 4、register
%%
clc;clear;close all;
addpath(genpath(pwd));
% Path is the data folder
Path = 'D:\lqh\zy\data';
Path1=strcat(Path,'\Result');
if exist(Path1,'dir')==7  
    disp("Folder has been done.")
else
    mkdir(Path1);
end
% get the register images information, first image choose is strip,next is overall image
[FixedimgInfo,MovingimgInfo]=readNeedRegisterImg(Path);

% [FixedimgInfo,MovingimgInfo]=ImgRotate(FixedimgInfo,MovingimgInfo,Path1);
% relevant parameter setting
parameter=SetParameter();

% deal Strip Image 
if  parameter.FlagFixed==0
    StripImgInfo.Stripimgfile = FixedimgInfo.Fixedimgfile;
    StripImgInfo.Stripimgallpath=FixedimgInfo.Fixedimgallpath;
    StripImgInfo.Stripimg=FixedimgInfo.Fixedimg;
else
    StripImgInfo.Stripimgfile = MovingimgInfo.Movingimgfile;
    StripImgInfo.Stripimgallpath=MovingimgInfo.Movingimgallpath;
    StripImgInfo.Stripimg=MovingimgInfo.Movingimg;
end
[StripImgInfo,parameter]=OnlySaveStripInfo(parameter,StripImgInfo,Path1);

% get correspond channel Strip
[StripImgInfo,parameter]=getCorrespondChannelStripInfo(StripImgInfo,parameter,Path1);
if  parameter.FlagFixed==0
    FixedimgInfo.Fixedimgfile=StripImgInfo.Stripimgfile;
    FixedimgInfo.Fixedimgallpath=StripImgInfo.Stripimgallpath;
    FixedimgInfo.Fixedimg=StripImgInfo.Stripimg;
else
    MovingimgInfo.Movingimgfile=StripImgInfo.Stripimgfile;
    MovingimgInfo.Movingimgallpath=StripImgInfo.Stripimgallpath;   
    MovingimgInfo.Movingimg=StripImgInfo.Stripimg;
end

% Make image in same size,notice first parameter is fixed image,next
% parameter is croped image
MovingimgInfo=MakeStripAndOverallInSameSize(FixedimgInfo,MovingimgInfo,parameter,Path1);

% Make two image register
movingReg=MakeRegister(FixedimgInfo,MovingimgInfo,parameter,Path1);
% movingReg=MakeRegister1(FixedimgInfo,MovingimgInfo,parameter,Path1);






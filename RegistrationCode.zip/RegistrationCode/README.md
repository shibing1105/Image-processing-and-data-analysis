# Feature-based Geometric Transformation Image Registration
# Contents

- [Overview](#overview)
- [System requirements](#system-requirements)
- [File structure](#file-structure)
- [Operating Instructions](#operating-instructions)


# Overview

This method combines multiple feature description techniques (e.g., KAZE, SIFT, BRISK, corner) to extract and match keypoints in the images, and then applies a geometric transformation to align the matched points, achieving image registration.
1. Image Preprocessing
The images are first preprocessed by applying edge detection to extract main structures, followed by dilation to enhance edge connectivity, and then binarization to identify the coordinates of non-zero signal regions.
2. Feature Description Matching
* Method 1
For these signal points, multiple feature detection methods (e.g., KAZEPoints, SIFTPoints, cornerPoints, BRISKPoints) are applied to extract feature descriptors, and feature matching is performed for each method.
* Method 2
Spatial domain cross-correlation may be employed to calculate translation values. Following correction, mutual information is computed between the corrected image and the registered image. If the mutual information exceeds a predetermined threshold, N signal points are randomly selected from the registered image to serve as reference points for subsequent geometric transformations. Otherwise, method 1 is applied to obtain matched feature points.
3. Geometric Transformation
The resulting matched points from different methods are then filtered, and those with better matching quality are retained as reference points for estimating the geometric transformation.

# System requirements
* The software was tested on a *Windows* system with Windows 11 Home. 
* The code was tested with MATLAB version R2020b.
Note: Some functions or performance may vary across different versions. It is recommended to use R2022b for experiments.
# File structure
Main Code Description
* function
    Folder code is a relevant functional function used for registration.

* main.m
    The code extracts and matches keypoints using multiple feature descriptors (KAZE, SIFT, BRISK), then applies a geometric transformation for image registration. 

* SetParameter.m
    The code is used for relevant parameter settings.

* CalibrationRegisterROI.m
    The code employs spatial domain cross-correlation to perform secondary correction on registered local image regions, thereby achieving more precise alignment of finer local areas.

# Operating Instructions
### Step 1 
Select the images to be processed and configure the parameters.
#### Setting Parameter
| Parameter Name | Parameter description | 
| :-----| :---- |
| channel | Channel corresponding to the strip image  | 
| block_interval_distance | The spacing distance between image blocks | 
| blocksize | The size of image blocks  |
| StripNum | The corresponding channel strip's position on the entire strip image from left to right   |
| StripCropImgSize | The crop size of removing non-strip information  |
| CropImgSize | The crop size of corresponding channel strip information  |
| RoughRegisterNum | The number of initial registrations using phase correlation |
| total_StripNum | The total number of entire strip image  |
| FlagFixed |  Whether the fixed image is a strip image  |
| gauss_sigma | The sigma corresponding to Gaussian preprocessing of the image |
### Step 2
Preprocess the stripe images by removing non-stripe regions, cropping channel areas, standardizing pixel dimensions, and performing initial registration via spatial domain cross-correlation. 
### Setp 3
Divide the images into 1000×1000(the value depends on the width of the individual strip and is generally set slightly larger) image blocks and achieve local optimization registration using multiple feature point matching methods.
### Step 4
Locally matched feature points are mapped onto the global image, and geometric transformations are applied based on this mapping to achieve globally optimized registration.


function parameter=SetParameter()
    prompt = {'channel:', 'block_interval_distance:', 'blocksize:', 'MaxRatio:', 'StripNum','StripCropImgSize', 'CropImgSize:', 'RoughRegisterNum:', 'total_StripNum:', 'FlagFixed(0 is Strip):', 'gauss_sigma:'};
    title = 'Variable Settings';
    dims = [1 50];
    % Strip Num is encode from left to right 
    definput = {'487', '[1000,500]', '[1000,1000]','0.8', '[7,8]', '[3000,2000]', '[2000,3000]','3', '16', '0','0.5'};
    user_input = inputdlg(prompt, title, dims, definput);
    parameter.channel = user_input{1};  
    parameter.block_interval_distance=str2num(user_input{2});    
    parameter.blocksize=str2num(user_input{3});       
    parameter.MaxRatio=str2double(user_input{4});   
    parameter.StripNum=str2num(user_input{5});
    parameter.StripCropImgSize=str2num(user_input{6});
    parameter.CropImgSize=str2num(user_input{7});
    parameter.RoughRegisterNum=str2double(user_input{8});
    parameter.total_StripNum=str2double(user_input{9});
    parameter.FlagFixed=str2double(user_input{10});
    parameter.gauss_sigma=str2double(user_input{11});
end
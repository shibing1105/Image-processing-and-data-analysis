path1="D:\lqh\zy\code\img1.tiff";
path2="D:\lqh\zy\code\img2.tiff";
roi1=imread(path1);
roi2=imread(path2);

[moving_x1,moving_y1]=overlop_PhaseCorrelation(roi1,roi2);
[rows,cols]=size(roi2);
corret_roi2=zeros(rows,cols);
if moving_x1>0
    if moving_y1>0
        corret_roi2(1:rows-moving_y1,1:cols-moving_x1)=roi2(moving_y1+1:end,moving_x1+1:end);
    else
        corret_roi2(abs(moving_y1)+1:end,:)=roi2(1:rows-abs(moving_y1),moving_x1+1:moving_x1+cols);
    end
else
    if moving_y1>0
        corret_roi2(:,abs(moving_x1)+1:end)=roi2(moving_y1+1:moving_y1+rows,1:cols-abs(moving_x1));
    else
        corret_roi2(abs(moving_y1)+1:end,abs(moving_x1)+1:end)=roi2(1:rows-abs(moving_y1),1:cols-abs(moving_x1));
    end
end
figure();
imshowpair(roi1,corret_roi2);
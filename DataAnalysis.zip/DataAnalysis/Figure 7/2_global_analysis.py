import os
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
import numpy as np
from scipy.stats import spearmanr

# --- Configuration ---
SCRIPT_DIR = os.path.abspath(os.path.dirname(__file__))
RESULTS_DIR = os.path.join(SCRIPT_DIR, "results")

# This script reads the output of script 1
INPUT_CSV = os.path.join(RESULTS_DIR, "all_cells_processed_master_scaffold.csv")
# This script creates its own output subdirectory
OUTPUT_DIR = os.path.join(RESULTS_DIR, "global_analysis_output")
os.makedirs(OUTPUT_DIR, exist_ok=True)

GLOBAL_MARKERS = ["CD20", "GFAP", "CD68", "CD8a", "CD4", "CD34"]
COL_X = "x"
COL_Y = "y"


# --- Script Functions ---
def plot_density_heatmaps(df, markers):
    """
    Generates and saves density heatmaps (KDE plots) for each specified marker.
    """
    print("Generating density heatmaps for each global marker...")
    n_markers = len(markers)
    n_cols = 3
    n_rows = (n_markers + n_cols - 1) // n_cols
    fig, axes = plt.subplots(n_rows, n_cols, figsize=(6 * n_cols, 4.5 * n_rows))
    axes = axes.flatten()
    fig.suptitle("Global Density of Environmental Markers", fontsize=16, y=1.02)

    # **[Core Correction]** Set axes based on actual data range, not hardcoded pixel sizes
    xlim = (df[COL_X].min(), df[COL_X].max())
    # Y-axis must be inverted to match image coordinates (0,0 at top-left)
    ylim = (df[COL_Y].max(), df[COL_Y].min())

    for i, marker in enumerate(markers):
        ax = axes[i]
        marker_df = df[df[f"{marker}_pos"] == 1]

        if len(marker_df) < 5:
            ax.set_title(f"{marker} (N={len(marker_df)})")
            ax.text(0.5, 0.5, "Too few cells", ha='center', va='center', transform=ax.transAxes, color='grey')
        else:
            sns.kdeplot(data=marker_df, x=COL_X, y=COL_Y, fill=True, thresh=0.05, cmap="viridis", ax=ax)
            ax.set_title(f"{marker} (N={len(marker_df)})")

        ax.set_aspect('equal', adjustable='box')
        ax.set_xlim(xlim)
        ax.set_ylim(ylim)
        ax.xaxis.tick_top()
        ax.xaxis.set_label_position('top')
        ax.set_xlabel("X coordinate (µm)")
        ax.set_ylabel("Y coordinate (µm)")

    # Hide unused subplots
    for j in range(i + 1, len(axes)):
        fig.delaxes(axes[j])

    plt.tight_layout(rect=[0, 0, 1, 0.98])
    png_path = os.path.join(OUTPUT_DIR, "global_density_heatmaps.png")
    svg_path = os.path.join(OUTPUT_DIR, "global_density_heatmaps.svg")
    plt.savefig(png_path, dpi=300)
    plt.savefig(svg_path, format='svg')
    plt.close()
    print(f"  -> Global density maps saved to: {os.path.basename(png_path)}/.svg")


def plot_spatial_correlation_matrix(df, markers, grid_size=100):
    """
    Calculates and plots a spatial correlation matrix using a grid-based method.
    """
    print("\nCalculating global spatial correlation via grid method...")
    df_copy = df.copy()

    # **[Core Correction]** Grid division is also based on the actual data range
    x_min, x_max = df_copy[COL_X].min(), df_copy[COL_X].max()
    y_min, y_max = df_copy[COL_Y].min(), df_copy[COL_Y].max()

    x_bins = np.linspace(x_min, x_max, grid_size + 1)
    y_bins = np.linspace(y_min, y_max, grid_size + 1)

    df_copy['grid_x'] = pd.cut(df_copy[COL_X], bins=x_bins, labels=False, include_lowest=True)
    df_copy['grid_y'] = pd.cut(df_copy[COL_Y], bins=y_bins, labels=False, include_lowest=True)
    df_copy['grid_id'] = df_copy['grid_x'].astype(str) + '_' + df_copy['grid_y'].astype(str)

    # Count cells of each marker type in each grid square
    grid_counts = [df_copy[df_copy[f"{m}_pos"] == 1].groupby('grid_id').size().rename(m) for m in markers]
    count_df = pd.concat(grid_counts, axis=1).fillna(0)

    # Calculate Spearman correlation
    corr_matrix, _ = spearmanr(count_df)
    corr_df = pd.DataFrame(corr_matrix, index=count_df.columns, columns=count_df.columns)

    # Save data for Prism
    prism_corr_path = os.path.join(OUTPUT_DIR, "prism_data_global_correlation.csv")
    corr_df.to_csv(prism_corr_path)
    print(f"  -> Correlation matrix data exported to: {os.path.basename(prism_corr_path)}")

    # Plot heatmap
    plt.figure(figsize=(10, 8))
    sns.heatmap(corr_df, annot=True, fmt=".2f", cmap="vlag", center=0, linewidths=.5)
    plt.title(f"Global Spatial Correlation of Cell Types (Grid Size: {grid_size}x{grid_size})")
    plt.xticks(rotation=45, ha='right')
    plt.yticks(rotation=0)
    plt.tight_layout()

    png_path = os.path.join(OUTPUT_DIR, "global_spatial_correlation_matrix.png")
    svg_path = os.path.join(OUTPUT_DIR, "global_spatial_correlation_matrix.svg")
    plt.savefig(png_path, dpi=300)
    plt.savefig(svg_path, format='svg')
    plt.close()
    print(f"  -> Global correlation heatmap saved to: {os.path.basename(png_path)}/.svg")


def main():
    print("--- Step 2: Starting Global Spatial Analysis ---")
    if not os.path.exists(INPUT_CSV):
        print(f"Error: Input file not found '{INPUT_CSV}'. Please run script 1 first.")
        return

    df = pd.read_csv(INPUT_CSV)
    print(f"Data loaded, total cells: {len(df)}")

    plot_density_heatmaps(df, GLOBAL_MARKERS)
    plot_spatial_correlation_matrix(df, GLOBAL_MARKERS)

    print(f"\n--- Global Analysis Complete! ---\nAll charts and data saved to:\n{OUTPUT_DIR}")


if __name__ == "__main__":
    main()

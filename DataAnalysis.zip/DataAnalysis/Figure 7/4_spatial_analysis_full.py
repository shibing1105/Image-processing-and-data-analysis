import os
import pandas as pd
from tqdm import tqdm
import numpy as np
from scipy.spatial import cKDTree
from joblib import Parallel, delayed
from statsmodels.stats.multitest import multipletests
import warnings

# --- Configuration ---
SCRIPT_DIR = os.path.abspath(os.path.dirname(__file__))
RESULTS_DIR = os.path.join(SCRIPT_DIR, "results")

INPUT_CSV = os.path.join(RESULTS_DIR, "all_cells_processed_master_scaffold.csv")
OUTPUT_DIR = os.path.join(RESULTS_DIR, "spatial_analysis_output_20um")
os.makedirs(OUTPUT_DIR, exist_ok=True)

RADIUS = 20.0  # Interaction radius in microns
R_GUARD = 50.0  # Guard rail distance from strip edge to avoid edge effects
N_PERM = 200  # Number of permutations for significance testing
N_JOBS = -1  # Number of cores for parallel processing (-1 = all cores)

ENV_MARKERS = ["CD20", "GFAP", "CD68", "CD8a", "CD4", "CD34"]
DIAG_MARKERS_MAP = {
    1: "CD45", 2: "VIM", 3: "CD20", 4: "CD79A", 5: "CD3", 6: "CD34",
    7: "CD5", 8: "Ki67", 9: "CD10", 10: "CD4", 11: "CD68", 12: "c-Myc",
    13: "CD8a", 14: "Bcl-6", 15: "MUM1", 16: "Bcl-2"
}
COL_X, COL_Y, COL_STRIP = "x", "y", "strip_id"


# --- Script Functions ---
def add_dist_to_strip_edge(df_strip):
    """Calculates distance to the nearest edge for each cell in a strip."""
    x_min, x_max = df_strip[COL_X].min(), df_strip[COL_X].max()
    y_min, y_max = df_strip[COL_Y].min(), df_strip[COL_Y].max()
    return np.minimum.reduce(
        [df_strip[COL_X] - x_min, x_max - df_strip[COL_X],
         df_strip[COL_Y] - y_min, y_max - df_strip[COL_Y]])


def get_core_cells(df, strip_id, r_guard=R_GUARD):
    """Extracts cells from a strip, identifying 'core' cells away from the edge."""
    df_strip = df[df[COL_STRIP] == strip_id].copy()
    if len(df_strip) == 0:
        return df_strip, df_strip
    df_strip['dist_to_edge'] = add_dist_to_strip_edge(df_strip)
    return df_strip, df_strip[df_strip['dist_to_edge'] >= r_guard].copy()


def compute_metrics_for_group(df_full, cell_indices, env_markers, neighbors_list):
    """Calculates 'fraction with neighbor' metric for a group of cells."""
    env_pos_global = {e: df_full[f"{e}_pos"].values.astype(bool) for e in env_markers}
    frac_with = {}

    # Use global indices (from df_full.index)
    cell_indices_loc = df_full.index.get_indexer(cell_indices)

    for env in env_markers:
        env_fracs = []
        for loc_idx, global_idx in zip(cell_indices_loc, cell_indices):
            if loc_idx == -1: continue  # Should not happen if indices are correct

            # Neighbors are stored by positional index
            neighbor_global_indices = df_full.index[neighbors_list[loc_idx]]
            true_neighbors = [n_idx for n_idx in neighbor_global_indices if n_idx != global_idx]

            if not true_neighbors:
                env_fracs.append(0)
                continue

            # Check positivity of neighbors
            neighbor_locs = df_full.index.get_indexer(true_neighbors)
            valid_neighbor_locs = neighbor_locs[neighbor_locs != -1]
            if len(valid_neighbor_locs) == 0:
                env_fracs.append(0)
                continue

            count = env_pos_global[env][valid_neighbor_locs].sum()
            env_fracs.append(1 if count > 0 else 0)

        frac_with[env] = np.mean(env_fracs) if env_fracs else np.nan
    return {'frac_with': frac_with}


def permutation_test_internal(df_full, df_core, marker, env, neighbors_list, n_perm, n_jobs):
    """Performs permutation test within a strip."""
    marker_pos_col = f"{marker}_pos"
    core_pos_indices = df_core[df_core[marker_pos_col] == 1].index.values
    core_neg_indices = df_core[df_core[marker_pos_col] == 0].index.values

    if len(core_pos_indices) * len(core_neg_indices) == 0:
        return np.nan, np.nan, np.nan, np.nan

    obs_pos_metrics = compute_metrics_for_group(df_full, core_pos_indices, [env], neighbors_list)
    obs_neg_metrics = compute_metrics_for_group(df_full, core_neg_indices, [env], neighbors_list)
    obs_pos_frac, obs_neg_frac = obs_pos_metrics['frac_with'][env], obs_neg_metrics['frac_with'][env]

    if pd.isna(obs_pos_frac) or pd.isna(obs_neg_frac):
        return np.nan, np.nan, np.nan, np.nan

    observed_diff = obs_pos_frac - obs_neg_frac
    all_core_indices = np.concatenate([core_pos_indices, core_neg_indices])

    def run_permutation_batch(num_perms, seed):
        np.random.seed(seed)
        diffs = []
        for _ in range(num_perms):
            perm_indices = np.random.permutation(all_core_indices)
            pos, neg = perm_indices[:len(core_pos_indices)], perm_indices[len(core_pos_indices):]
            pos_m = compute_metrics_for_group(df_full, pos, [env], neighbors_list)
            neg_m = compute_metrics_for_group(df_full, neg, [env], neighbors_list)
            if pd.notna(pos_m['frac_with'][env]) and pd.notna(neg_m['frac_with'][env]):
                diffs.append(pos_m['frac_with'][env] - neg_m['frac_with'][env])
        return diffs

    n_jobs = os.cpu_count() if n_jobs == -1 else n_jobs
    n_jobs = min(n_jobs, n_perm, os.cpu_count())  # Be reasonable
    perms_per_job = [n_perm // n_jobs] * n_jobs
    for i in range(n_perm % n_jobs):
        perms_per_job[i] += 1

    job_seeds = np.random.randint(0, 2 ** 31 - 1, size=n_jobs)
    results = Parallel(n_jobs=n_jobs)(delayed(run_permutation_batch)(n, s) for n, s in zip(perms_per_job, job_seeds))
    perm_diffs = np.array([item for sublist in results for item in sublist])

    if len(perm_diffs) == 0:
        return obs_pos_frac, obs_neg_frac, np.nan, np.nan

    pval = (np.sum(np.abs(perm_diffs) >= np.abs(observed_diff)) + 1) / (len(perm_diffs) + 1)
    enrichment = obs_pos_frac / (obs_neg_frac + 1e-9)
    return obs_pos_frac, obs_neg_frac, pval, enrichment


def compute_neighborhood_composition(df_full, cell_indices, env_markers, neighbors_list):
    """Calculates the average composition of the neighborhood for a group of cells."""
    if not cell_indices.any():
        return {e: np.nan for e in env_markers}

    env_pos_global = {e: df_full[f"{e}_pos"].values.astype(bool) for e in env_markers}
    cell_indices_loc = df_full.index.get_indexer(cell_indices)
    compositions = []

    for loc_idx, global_idx in zip(cell_indices_loc, cell_indices):
        if loc_idx == -1: continue

        neighbor_global_indices = df_full.index[neighbors_list[loc_idx]]
        true_neighbors_global = [n_idx for n_idx in neighbor_global_indices if n_idx != global_idx]

        if not true_neighbors_global:
            continue

        true_neighbors_loc = df_full.index.get_indexer(true_neighbors_global)
        valid_neighbor_locs = true_neighbors_loc[true_neighbors_loc != -1]

        if len(valid_neighbor_locs) == 0:
            continue

        env_counts = {e: env_pos_global[e][valid_neighbor_locs].sum() for e in env_markers}
        total = sum(env_counts.values())
        if total > 0:
            compositions.append({e: env_counts[e] / total for e in env_markers})

    if not compositions:
        return {e: 0 for e in env_markers}

    return pd.DataFrame(compositions).mean().to_dict()


def get_per_cell_neighbor_counts(df_full, cell_indices, env_marker, neighbors_list):
    """Gets a list of neighbor counts for each cell in a group."""
    env_pos_global = df_full[f"{env_marker}_pos"].values
    cell_indices_loc = df_full.index.get_indexer(cell_indices)
    counts = []

    for loc_idx, global_idx in zip(cell_indices_loc, cell_indices):
        if loc_idx == -1: continue

        neighbor_global_indices = df_full.index[neighbors_list[loc_idx]]
        true_neighbors_global = [n_idx for n_idx in neighbor_global_indices if n_idx != global_idx]

        if not true_neighbors_global:
            counts.append(0)
            continue

        true_neighbors_loc = df_full.index.get_indexer(true_neighbors_global)
        valid_neighbor_locs = true_neighbors_loc[true_neighbors_loc != -1]

        if len(valid_neighbor_locs) == 0:
            counts.append(0)
            continue

        counts.append(env_pos_global[valid_neighbor_locs].sum())

    return counts


def main():
    print("--- Core Spatial Analysis (Final scientific-fix version) ---")
    df = pd.read_csv(INPUT_CSV, index_col='cell_id')

    print("Building global k-d tree...")
    tree = cKDTree(df[[COL_X, COL_Y]].values)
    print(f"Querying all neighbors within {RADIUS}µm...")
    neighbors_list = tree.query_ball_point(df[[COL_X, COL_Y]].values, RADIUS)

    results_rows = []

    # Configuration for a specific deep-dive plot
    DEEP_DIVE_STRIP_ID = 15  # e.g., MUM1
    DEEP_DIVE_ENV_MARKER = "CD8a"
    DEEP_DIVE_DIAG_MARKER = DIAG_MARKERS_MAP.get(DEEP_DIVE_STRIP_ID, "Unknown")

    pbar = tqdm(DIAG_MARKERS_MAP.items(), desc="Analyzing each strip")
    for strip_id, marker in pbar:
        _, df_core = get_core_cells(df, strip_id, r_guard=R_GUARD)
        if len(df_core) < 20:
            # print(f"Skipping strip {strip_id} ({marker}): Not enough core cells.")
            continue

        # --- Deep Dive Data Export ---
        if strip_id == DEEP_DIVE_STRIP_ID:
            pbar.set_description(f"Analyzing {marker} (running deep dive)")
            pos_indices = df_core[df_core[f"{DEEP_DIVE_DIAG_MARKER}_pos"] == 1].index.values
            neg_indices = df_core[df_core[f"{DEEP_DIVE_DIAG_MARKER}_pos"] == 0].index.values
            pos_counts = get_per_cell_neighbor_counts(df, pos_indices, DEEP_DIVE_ENV_MARKER, neighbors_list)
            neg_counts = get_per_cell_neighbor_counts(df, neg_indices, DEEP_DIVE_ENV_MARKER, neighbors_list)
            deep_dive_df = pd.DataFrame({'neighbor_count': pos_counts + neg_counts,
                                         'group': ['Positive'] * len(pos_counts) + ['Negative'] * len(neg_counts)})
            deep_dive_path = os.path.join(OUTPUT_DIR,
                                          f"deep_dive_data_{DEEP_DIVE_DIAG_MARKER}_vs_{DEEP_DIVE_ENV_MARKER}.csv")
            deep_dive_df.to_csv(deep_dive_path, index=False)
            print(f"  -> Deep dive data saved for {DEEP_DIVE_DIAG_MARKER}")
        else:
            pbar.set_description(f"Analyzing {marker}")

        # --- Standard Analysis ---
        core_pos_indices = df_core[df_core[f"{marker}_pos"] == 1].index.values
        composition = compute_neighborhood_composition(df, core_pos_indices, ENV_MARKERS, neighbors_list)

        internal_perms = {}
        for env in ENV_MARKERS:
            with warnings.catch_warnings():
                warnings.simplefilter("ignore", category=RuntimeWarning)  # Ignore empty slice warnings
                pos_frac, neg_frac, pval, enrich = permutation_test_internal(df, df_core, marker, env, neighbors_list,
                                                                             N_PERM, N_JOBS)
            internal_perms[env] = {'pos_frac': pos_frac, 'neg_frac': neg_frac, 'pval': pval, 'enrich': enrich}

        row = {'strip_id': strip_id, 'marker': marker}
        r_prefix = f'r{int(RADIUS)}'
        for env in ENV_MARKERS:
            row[f'{r_prefix}_pos_frac_with_{env}'] = internal_perms[env]['pos_frac']
            row[f'{r_prefix}_neg_frac_with_{env}'] = internal_perms[env]['neg_frac']
            row[f'perm_internal_pval_{env}'] = internal_perms[env]['pval']
            row[f'perm_internal_enrichment_{env}'] = internal_perms[env]['enrich']
            row[f'composition_{env}'] = composition.get(env, np.nan)
        results_rows.append(row)

    summary_df = pd.DataFrame(results_rows)

    print("\nApplying FDR correction to p-values...")
    p_cols = [c for c in summary_df.columns if c.startswith('perm_internal_pval_')]
    if p_cols:
        p_vals_flat = summary_df[p_cols].values.flatten()
        not_na_mask = ~pd.isna(p_vals_flat)
        if np.any(not_na_mask):
            _, p_adj, _, _ = multipletests(p_vals_flat[not_na_mask], alpha=0.05, method='fdr_bh')
            p_adj_full = np.full(p_vals_flat.shape, np.nan)
            p_adj_full[not_na_mask] = p_adj
            adj_p_reshaped = p_adj_full.reshape(summary_df[p_cols].shape)
            for i, col in enumerate(p_cols):
                summary_df[f'fdr_{col}'] = adj_p_reshaped[:, i]

    summary_df.to_csv(os.path.join(OUTPUT_DIR, "stripe_summary_final.csv"), index=False)
    print(
        f"\n--- Core Analysis Complete! ---\nAll statistical results saved to:\n{os.path.join(OUTPUT_DIR, 'stripe_summary_final.csv')}")


if __name__ == "__main__":
    main()

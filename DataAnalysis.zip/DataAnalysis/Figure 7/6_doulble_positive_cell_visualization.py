import os
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
import numpy as np
from scipy.spatial import cKDTree
from tqdm import tqdm
from statsmodels.stats.multitest import multipletests
from matplotlib.patches import Circle
from matplotlib.lines import Line2D

# --- Configuration ---
SCRIPT_DIR = os.path.abspath(os.path.dirname(__file__))
RESULTS_DIR = os.path.join(SCRIPT_DIR, "results")

INPUT_CSV = os.path.join(RESULTS_DIR, "all_cells_processed_master_scaffold.csv")
OUTPUT_DIR = os.path.join(RESULTS_DIR, "deep_dive_composite_plots")
os.makedirs(OUTPUT_DIR, exist_ok=True)

RADIUS = 20.0
N_PERM = 500
TUMOR_MARKER = "CD20"
ENV_MARKERS = ["CD8a", "CD4", "CD68", "CD34", "GFAP"]
FOCUS_STRIPS = {
    14: "Bcl-6", 16: "Bcl-2", 15: "MUM1", 12: "c-Myc"
}
COL_X, COL_Y, COL_STRIP = "x", "y", "strip_id"


# --- Core Functions (Corrected) ---

def compute_frac_with(df_global, cell_indices, env_marker_indices, radius):
    """[Corrected] This function now always uses global df positional indices for coordinates"""
    if len(cell_indices) == 0 or len(env_marker_indices) == 0:
        return np.nan

    # Ensure inputs are numpy arrays
    cell_indices = np.array(cell_indices)
    env_marker_indices = np.array(env_marker_indices)

    # Use .iloc, as cell_indices are now integer positional indices
    source_coords = df_global.iloc[cell_indices][[COL_X, COL_Y]].values
    target_coords = df_global.iloc[env_marker_indices][[COL_X, COL_Y]].values

    if target_coords.shape[0] == 0:
        return 0.0  # No targets, so fraction is zero

    tree = cKDTree(target_coords)
    neighbor_counts = tree.query_ball_point(source_coords, r=radius, return_length=True)

    # Check if self is in the target group
    # Note: these are global positional indices
    self_in_target_mask = np.isin(cell_indices, env_marker_indices)
    neighbor_counts[self_in_target_mask] = np.maximum(0, neighbor_counts[self_in_target_mask] - 1)

    return np.mean(neighbor_counts > 0)


def run_permutation(df_global, group1_indices, group2_indices, env_marker_indices, radius, n_perm):
    """[Corrected] Ensure all calls to compute_frac_with pass the global df"""
    obs_frac1 = compute_frac_with(df_global, group1_indices, env_marker_indices, radius)
    obs_frac2 = compute_frac_with(df_global, group2_indices, env_marker_indices, radius)
    if pd.isna(obs_frac1) or pd.isna(obs_frac2):
        return np.nan, np.nan, np.nan, np.nan

    observed_diff = obs_frac1 - obs_frac2
    all_indices = np.concatenate([group1_indices, group2_indices])
    perm_diffs = []

    for _ in range(n_perm):
        perm_indices = np.random.permutation(all_indices)
        perm_g1, perm_g2 = perm_indices[:len(group1_indices)], perm_indices[len(group1_indices):]
        frac1 = compute_frac_with(df_global, perm_g1, env_marker_indices, radius)
        frac2 = compute_frac_with(df_global, perm_g2, env_marker_indices, radius)
        if pd.notna(frac1) and pd.notna(frac2):
            perm_diffs.append(frac1 - frac2)

    if len(perm_diffs) == 0:
        return obs_frac1, obs_frac2, np.nan, np.nan

    pval = (np.sum(np.abs(perm_diffs) >= np.abs(observed_diff)) + 1) / (len(perm_diffs) + 1)
    enrichment = obs_frac1 / (obs_frac2 + 1e-9)
    return obs_frac1, obs_frac2, pval, enrichment


def get_per_cell_neighbor_counts(df_global, cell_indices, env_marker_indices, radius):
    """[Corrected] Ensure use of global df"""
    if len(cell_indices) == 0 or len(env_marker_indices) == 0:
        return np.array([])

    source_coords = df_global.iloc[cell_indices][[COL_X, COL_Y]].values
    target_coords = df_global.iloc[env_marker_indices][[COL_X, COL_Y]].values

    if target_coords.shape[0] == 0:
        return np.zeros(len(cell_indices))

    tree = cKDTree(target_coords)
    counts = tree.query_ball_point(source_coords, r=radius, return_length=True)
    self_in_target_mask = np.isin(cell_indices, env_marker_indices)
    counts[self_in_target_mask] = np.maximum(0, counts[self_in_target_mask] - 1)
    return counts


def find_representative_roi(df_global, df_strip, group_indices_loc, env_marker_indices_loc, radius, tile_size=100.0):
    """[Corrected] Ensure all calls to compute_frac_with pass the global df"""
    if len(group_indices_loc) == 0:
        return None

    overall_frac = compute_frac_with(df_global, group_indices_loc, env_marker_indices_loc, radius)
    if pd.isna(overall_frac):
        return None

    x_min, x_max = df_strip[COL_X].min(), df_strip[COL_X].max()
    y_min, y_max = df_strip[COL_Y].min(), df_strip[COL_Y].max()
    best_tile, min_diff = None, np.inf

    for x in np.arange(x_min, x_max, tile_size):
        for y in np.arange(y_min, y_max, tile_size):
            tile_bounds = (x, y, x + tile_size, y + tile_size)

            # Use integer positional indices
            tile_cells_idx_loc = df_strip.index[
                (df_strip[COL_X] >= tile_bounds[0]) & (df_strip[COL_X] < tile_bounds[2]) &
                (df_strip[COL_Y] >= tile_bounds[1]) & (df_strip[COL_Y] < tile_bounds[3])
                ].values

            tile_group_indices_loc = np.intersect1d(tile_cells_idx_loc, group_indices_loc)

            if len(tile_group_indices_loc) < 5:
                continue

            local_frac = compute_frac_with(df_global, tile_group_indices_loc, env_marker_indices_loc, radius)
            if pd.isna(local_frac):
                continue

            diff = abs(local_frac - overall_frac)
            if diff < min_diff:
                min_diff, best_tile = diff, tile_bounds
    return best_tile


# --- Main Execution (Refactored) ---
def main():
    print("--- Starting Double-Positive Cell Deep Dive & Composite Plot Generation (Final stable version) ---")

    try:
        df = pd.read_csv(INPUT_CSV)
    except FileNotFoundError:
        print(f"Error: Input file not found '{INPUT_CSV}'. Please run script 1 first.")
        return

    if 'cell_id' in df.columns:
        df = df.set_index('cell_id')

    # Reset index, so we can consistently use .iloc and integer positional indices
    df = df.reset_index(drop=True)

    # === Part 1: Data Summary and Statistical Tests ===
    print("\n===== Part 1: Aggregating statistics for all focus strips =====")
    all_stats = []
    for strip_id, diag_marker in FOCUS_STRIPS.items():
        if f"{diag_marker}_pos" not in df.columns or f"{TUMOR_MARKER}_pos" not in df.columns:
            print(
                f"  -> Warning: Marker columns for {diag_marker} or {TUMOR_MARKER} not found. Skipping strip {strip_id}.")
            continue

        df_strip = df[df[COL_STRIP] == strip_id]
        if df_strip.empty:
            print(f"  -> Info: No cells found for strip {strip_id} ({diag_marker}).")
            continue

        # Use integer positional indices .index.values
        double_pos_indices = df_strip[
            (df_strip[f"{diag_marker}_pos"] == 1) & (df_strip[f"{TUMOR_MARKER}_pos"] == 1)].index.values
        cd20_only_indices = df_strip[
            (df_strip[f"{diag_marker}_pos"] == 0) & (df_strip[f"{TUMOR_MARKER}_pos"] == 1)].index.values

        if len(double_pos_indices) < 5 or len(cd20_only_indices) < 5:
            print(
                f"  -> Warning: Too few cells in {diag_marker} strip (DP: {len(double_pos_indices)}, C20: {len(cd20_only_indices)}), skipping statistics.")
            continue

        for env_marker in tqdm(ENV_MARKERS, desc=f"  Analyzing {diag_marker}"):
            if f"{env_marker}_pos" not in df.columns:
                print(f"    -> Warning: Env marker {env_marker} not found. Skipping.")
                continue
            # Use integer positional indices .index.values
            env_marker_indices = df[df[f"{env_marker}_pos"] == 1].index.values
            frac_dp, frac_c20, pval, enrich = run_permutation(df, double_pos_indices, cd20_only_indices,
                                                              env_marker_indices, RADIUS, N_PERM)
            all_stats.append({'diag_marker': diag_marker, 'env_marker': env_marker, 'frac_double_pos': frac_dp,
                              'frac_cd20_only': frac_c20, 'pval': pval, 'enrichment': enrich})

    if not all_stats:
        print("Warning: Not enough data to generate any plots.")
        return

    all_stats_df = pd.DataFrame(all_stats).dropna()
    if all_stats_df.empty:
        print("Warning: All statistical results are invalid, cannot continue.")
        return

    _, all_stats_df['fdr'], _, _ = multipletests(all_stats_df['pval'], alpha=0.05, method='fdr_bh')
    all_stats_df['log2FC'] = np.log2(all_stats_df['enrichment'].clip(lower=1e-6))
    all_stats_df['-log10FDR'] = -np.log10(all_stats_df['fdr'].clip(lower=1e-50))

    # === Part 2: Generating "Composite Comparison Plots" ===
    print("\n===== Part 2: Generating Composite Comparison Plots =====")
    # **[Workflow Optimization & Error Handling]**
    try:
        # Faceted Volcano Plot
        g = sns.FacetGrid(all_stats_df, col="diag_marker", col_wrap=2, height=5, aspect=1, sharex=False, sharey=True)
        g.map(sns.scatterplot, "log2FC", "-log10FDR", s=100, color='royalblue', alpha=0.7)
        g.map(lambda **kwargs: (
            plt.axhline(-np.log10(0.05), ls='--', color='black', lw=1),
            plt.axvline(0, ls='--', color='grey', lw=1)))

        def label_points(x, y, label, **kwargs):
            df_points = pd.DataFrame({'x': x, 'y': y, 'label': label})
            sig_points = df_points[df_points['y'] > -np.log10(0.05)]
            for _, point in sig_points.iterrows():
                plt.text(point['x'] + 0.05, point['y'], point['label'], fontsize=9)

        g.map(label_points, "log2FC", "-log10FDR", "env_marker")
        g.set_titles("{col_name}")
        g.fig.suptitle("Volcano Plot Facet Grid", y=1.03)
        g.set_axis_labels("Log2(Enrichment)", "-Log10(FDR)")
        plt.savefig(os.path.join(OUTPUT_DIR, "composite_volcano_grid.png"), dpi=300)
        plt.savefig(os.path.join(OUTPUT_DIR, "composite_volcano_grid.svg"))
        plt.close()
        all_stats_df.to_csv(os.path.join(OUTPUT_DIR, "prism_data_volcano_all.csv"), index=False)
        print("  -> Faceted volcano plots and Prism data saved.")

        # **[Visual Upgrade]** New composite jittered dumbbell plot
        fig, ax = plt.subplots(figsize=(12, 8))
        diag_markers_order = sorted(list(FOCUS_STRIPS.values()))
        y_ticks = np.arange(len(diag_markers_order))
        ax.set_yticks(y_ticks)
        ax.set_yticklabels(diag_markers_order)
        colors = plt.cm.Paired(np.linspace(0, 1, len(ENV_MARKERS)))
        jitter = np.linspace(-0.25, 0.25, len(ENV_MARKERS))

        for i, env_marker in enumerate(ENV_MARKERS):
            plot_data = all_stats_df[all_stats_df['env_marker'] == env_marker].set_index('diag_marker').reindex(
                diag_markers_order)
            y_pos = y_ticks + jitter[i]

            # Plot lines
            ax.hlines(y=y_pos, xmin=plot_data['frac_cd20_only'], xmax=plot_data['frac_double_pos'], color=colors[i],
                      alpha=0.7, lw=1.5)
            # Plot start points (CD20 only)
            ax.scatter(plot_data['frac_cd20_only'], y_pos, color='white', s=80, zorder=3, edgecolor=colors[i], lw=1.5,
                       label=f'{env_marker} (CD20+ only)' if i == 0 else None)
            # Plot end points (Double Pos)
            ax.scatter(plot_data['frac_double_pos'], y_pos, color=colors[i], s=80, zorder=3,
                       label=f'{env_marker} (Double Pos)' if i == 0 else None)

        ax.set_title('Composite Jittered Dumbbell Plot')
        ax.set_xlabel('Fraction with Neighbor')
        ax.grid(True, axis='x', linestyle='--', alpha=0.6)
        for y in y_ticks[:-1]:
            ax.axhline(y + 0.5, color='grey', linestyle=':', lw=0.5)

        # Create custom legend
        legend_elements = [
                              Line2D([0], [0], marker='o', color='w', label='CD20+ only', markerfacecolor='w',
                                     markeredgecolor='gray', markersize=10),
                              Line2D([0], [0], marker='o', color='w', label='Double Positive', markerfacecolor='gray',
                                     markeredgecolor='gray', markersize=10)
                          ] + [
                              Patch(facecolor=colors[i], edgecolor=colors[i], label=ENV_MARKERS[i]) for i in
                              range(len(ENV_MARKERS))
                          ]
        ax.legend(handles=legend_elements, title="Env Marker / Group", bbox_to_anchor=(1.05, 1), loc='upper left')

        plt.tight_layout()
        plt.savefig(os.path.join(OUTPUT_DIR, "composite_dumbbell_jitter.png"), dpi=300)
        plt.savefig(os.path.join(OUTPUT_DIR, "composite_dumbbell_jitter.svg"))
        plt.close()
        all_stats_df.to_csv(os.path.join(OUTPUT_DIR, "prism_data_dumbbell_all.csv"), index=False)
        print("  -> Composite jittered dumbbell plot and Prism data saved.")
    except Exception as e:
        print(f"  -> ****** Error: An error occurred while generating composite plots, skipped. ******")
        print(f"  -> Error message: {e}")

    # === Part 3: Generating "Individual Deep-Dive Plots" ===
    print("\n===== Part 3: Generating Individual Deep-Dive Plots =====")
    for strip_id, diag_marker in FOCUS_STRIPS.items():
        # **[Added Error Handling]**
        try:
            print(f"\n--- Deep dive for strip {strip_id}: {diag_marker} ---")
            strip_output_dir = os.path.join(OUTPUT_DIR, f"deep_dive_{diag_marker}")
            os.makedirs(strip_output_dir, exist_ok=True)

            df_strip = df[df[COL_STRIP] == strip_id]
            if df_strip.empty:
                print("  -> Info: Strip is empty. Skipping.")
                continue

            double_pos_indices = df_strip[
                (df_strip[f"{diag_marker}_pos"] == 1) & (df_strip[f"{TUMOR_MARKER}_pos"] == 1)].index.values
            cd20_only_indices = df_strip[
                (df_strip[f"{diag_marker}_pos"] == 0) & (df_strip[f"{TUMOR_MARKER}_pos"] == 1)].index.values
            marker_only_indices = df_strip[
                (df_strip[f"{diag_marker}_pos"] == 1) & (df_strip[f"{TUMOR_MARKER}_pos"] == 0)].index.values

            if len(double_pos_indices) < 5:
                print("  -> Warning: Too few double-positive cells, skipping deep dive for this strip.")
                continue

            # --- Distribution Plots ---
            for env_marker in ['CD8a', 'CD68']:
                if f"{env_marker}_pos" not in df.columns: continue

                env_marker_indices = df[df[f"{env_marker}_pos"] == 1].index.values
                dp_counts = get_per_cell_neighbor_counts(df, double_pos_indices, env_marker_indices, RADIUS)
                c20_counts = get_per_cell_neighbor_counts(df, cd20_only_indices, env_marker_indices, RADIUS)

                if len(dp_counts) == 0 and len(c20_counts) == 0:
                    print(f"  -> No count data for {env_marker}, skipping distribution plot.")
                    continue

                dist_df = pd.DataFrame({'count': np.concatenate([dp_counts, c20_counts]),
                                        'group': ['Double Positive'] * len(dp_counts) + ['CD20+ only'] * len(
                                            c20_counts)})
                dist_df.to_csv(os.path.join(strip_output_dir, f"prism_data_dist_vs_{env_marker}.csv"), index=False)

                plt.figure(figsize=(10, 6))
                sns.histplot(data=dist_df, x='count', hue='group', element='step', stat='density', common_norm=False,
                             kde=True)
                plt.title(f'Neighbor Count Dist ({diag_marker} vs {env_marker})')
                plt.xlabel(f"Number of {env_marker} neighbors within {RADIUS}µm")
                plt.savefig(os.path.join(strip_output_dir, f"dist_vs_{env_marker}.png"), dpi=300)
                plt.savefig(os.path.join(strip_output_dir, f"dist_vs_{env_marker}.svg"))
                plt.close()

            # --- Representative ROI Plot ---
            roi_env_marker = 'CD8a'
            if f"{roi_env_marker}_pos" not in df.columns: continue

            roi_env_indices = df[df[f"{roi_env_marker}_pos"] == 1].index.values
            roi_bounds = find_representative_roi(df, df_strip, double_pos_indices, roi_env_indices, RADIUS)

            if roi_bounds:
                print(
                    f"  -> {diag_marker} ROI found: X({roi_bounds[0]:.1f}, {roi_bounds[2]:.1f}), Y({roi_bounds[1]:.1f}, {roi_bounds[3]:.1f})")
                df_roi = df[
                    (df[COL_X] >= roi_bounds[0]) & (df[COL_X] < roi_bounds[2]) &
                    (df[COL_Y] >= roi_bounds[1]) & (df[COL_Y] < roi_bounds[3])]

                if df_roi.empty:
                    print("  -> ROI is empty, skipping scatter plot.")
                    continue

                plt.figure(figsize=(10, 10))
                ax = plt.gca()

                # Plot all other environment cells in grey
                env_marker_cols = [f"{m}_pos" for m in ENV_MARKERS]
                all_env_indices_roi = df_roi.index[df_roi[env_marker_cols].any(axis=1)]
                # Exclude cells we are plotting specifically
                exclude_indices = np.concatenate([marker_only_indices, cd20_only_indices, double_pos_indices])
                plot_env_indices = np.setdiff1d(all_env_indices_roi, exclude_indices)

                ax.scatter(df_roi.loc[plot_env_indices, COL_X], df_roi.loc[plot_env_indices, COL_Y], s=10,
                           color='lightgrey', alpha=0.7, label='Other Env. Cells')

                # Plot specific groups
                # df_roi.index already contains global positional indices, can be used directly
                ax.scatter(df_roi.loc[df_roi.index.intersection(marker_only_indices), COL_X],
                           df_roi.loc[df_roi.index.intersection(marker_only_indices), COL_Y], s=30, c='green',
                           marker='s', label=f'{diag_marker}+ only', zorder=3)
                ax.scatter(df_roi.loc[df_roi.index.intersection(cd20_only_indices), COL_X],
                           df_roi.loc[df_roi.index.intersection(cd20_only_indices), COL_Y], s=30, c='blue', marker='o',
                           label=f'{TUMOR_MARKER}+ only', zorder=3)
                ax.scatter(df_roi.loc[df_roi.index.intersection(double_pos_indices), COL_X],
                           df_roi.loc[df_roi.index.intersection(double_pos_indices), COL_Y], s=40, c='red', marker='^',
                           label=f'Double Positive', zorder=4, edgecolor='black')

                # Add example radius circles
                roi_dp_indices = df_roi.index.intersection(double_pos_indices)
                if len(roi_dp_indices) > 0:
                    example_indices = np.random.choice(roi_dp_indices,
                                                       size=min(5, len(roi_dp_indices)),
                                                       replace=False)
                    for idx in example_indices:
                        ax.add_patch(
                            Circle((df.loc[idx, COL_X], df.loc[idx, COL_Y]), RADIUS, color='red', fill=False, lw=0.8,
                                   alpha=0.7, zorder=5))

                # Add scale bar
                s_len = 20  # 20 µm
                s_x = roi_bounds[0] + 5
                s_y = roi_bounds[1] + 5
                ax.add_line(Line2D([s_x, s_x + s_len], [s_y, s_y], color='black', lw=2))
                ax.text(s_x + s_len / 2, s_y - 2, f'{s_len} µm', ha='center', va='top', fontsize=9)

                ax.set_aspect('equal')
                ax.legend(bbox_to_anchor=(1.05, 1), loc='upper left')
                ax.set_title(f'Representative ROI in {diag_marker} Strip')
                ax.set_xlabel("X coordinate (µm)")
                ax.set_ylabel("Y coordinate (µm)")
                plt.tight_layout()
                plt.savefig(os.path.join(strip_output_dir, "scatter_roi.png"), dpi=300)
                plt.savefig(os.path.join(strip_output_dir, "scatter_roi.svg"))
                plt.close()
            else:
                print("  -> No representative ROI found.")

        except Exception as e:
            print(f"  -> ****** Error: An error occurred while processing {diag_marker} strip, skipped. ******")
            print(f"  -> Error message: {e}")
            continue

    print(f"\n--- Deep Dive Analysis Complete! ---\nAll plots and data saved to:\n{OUTPUT_DIR}")


if __name__ == "__main__":
    main()

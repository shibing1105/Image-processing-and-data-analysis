import os
import pandas as pd
from tqdm import tqdm
import re
import numpy as np
from scipy.spatial import cKDTree

# --- Configuration ---
# Get the absolute path of the directory where the script is located
SCRIPT_DIR = os.path.abspath(os.path.dirname(__file__))
# Define data and results directories relative to the script directory
DATA_DIR = os.path.join(SCRIPT_DIR, "data")
RESULTS_DIR = os.path.join(SCRIPT_DIR, "results")
# Ensure the results directory exists
os.makedirs(RESULTS_DIR, exist_ok=True)

WHOLE_SLIDE_FILE = os.path.join(DATA_DIR, "Whole image.xlsx")
DIAG_MARKERS = [
    "CD45", "VIM", "CD20", "CD79A", "CD3", "CD34", "CD5", "Ki67",
    "CD10", "CD4", "CD68", "c-Myc", "CD8a", "Bcl-6", "MUM1", "Bcl-2"
]
STRIPE_FILENAMES = {marker: os.path.join(DATA_DIR, f"strip{marker}.xlsx") for marker in DIAG_MARKERS}
# Map strip_id to marker
DIAG_MARKERS_MAP = {i + 1: marker for i, marker in enumerate(DIAG_MARKERS)}

OUTPUT_CSV = os.path.join(RESULTS_DIR, "all_cells_processed_master_scaffold.csv")
PIXEL_TO_MICRON_SCALE = 200 / 360.9688
MATCHING_RADIUS_MICRONS = 3.0
ALL_MARKERS = DIAG_MARKERS + ["GFAP"]
COL_PHENOTYPE = "Classification"
COL_X_PIXEL = "Centroid X px"
COL_Y_PIXEL = "Centroid Y px"


# --- Script Functions ---
def read_and_clean_excel(file_path, strip_id, diag_marker=None):
    """
    Reads and cleans an Excel file from QuPath.
    """
    try:
        df = pd.read_excel(file_path, engine='openpyxl', header=0, usecols=[0, 1, 2],
                           names=[COL_PHENOTYPE, COL_X_PIXEL, COL_Y_PIXEL])
    except FileNotFoundError:
        print(f"Warning: File not found {file_path}, skipping.")
        return None
    df[COL_PHENOTYPE] = df[COL_PHENOTYPE].fillna("Unknown")
    if diag_marker:
        df[COL_PHENOTYPE] = df[COL_PHENOTYPE].str.replace('strip', diag_marker, regex=False)
    df = df.dropna(subset=[COL_X_PIXEL, COL_Y_PIXEL])
    df['x'] = df[COL_X_PIXEL] * PIXEL_TO_MICRON_SCALE
    df['y'] = df[COL_Y_PIXEL] * PIXEL_TO_MICRON_SCALE
    df['strip_id'] = strip_id
    return df


def parse_phenotypes(df, final_phenotype_col, all_markers):
    """
    Parses phenotype strings (e.g., "CD20:CD8a") into binary marker columns.
    """
    print("Parsing final phenotype labels...")
    for marker in all_markers:
        df[f"{marker}_pos"] = 0

    # Use .loc for safer assignment
    for index, row in tqdm(df.iterrows(), total=df.shape[0], desc="Parsing phenotypes"):
        phenotype_str = row[final_phenotype_col]
        if pd.isna(phenotype_str) or phenotype_str.lower() == 'unknown':
            continue
        detected_markers = re.split(r'\s*:\s*', str(phenotype_str))
        for marker in detected_markers:
            if marker in all_markers:
                df.loc[index, f"{marker}_pos"] = 1
    return df


# --- Main Execution ---
def main():
    print("--- Step 1: Starting Data Preprocessing (using global data as scaffold) ---")
    df_master = read_and_clean_excel(WHOLE_SLIDE_FILE, strip_id=0)
    if df_master is None:
        print(f"Error: Could not load master scaffold file: {WHOLE_SLIDE_FILE}")
        return
    master_cell_count = len(df_master)
    print(f"Scaffold loaded, containing {master_cell_count} cells.")

    stripe_dfs = []
    print("Reading and processing 16 stripe files as annotation sources...")
    # **[Correction]** Loop using the correct dictionary and mapping
    for strip_id, marker in tqdm(DIAG_MARKERS_MAP.items(), desc="Loading strips"):
        filepath = STRIPE_FILENAMES.get(marker)
        if filepath and os.path.exists(filepath):
            df_stripe = read_and_clean_excel(filepath, strip_id=strip_id, diag_marker=marker)
            if df_stripe is not None:
                stripe_dfs.append(df_stripe)
        elif filepath:
            print(f"Warning: File not found for marker {marker} at {filepath}, skipping.")

    if not stripe_dfs:
        print("Warning: No stripe data files were found or loaded. Proceeding with global data only.")
        df_strips_combined = pd.DataFrame(columns=['x', 'y', COL_PHENOTYPE, 'strip_id'])
    else:
        df_strips_combined = pd.concat(stripe_dfs, ignore_index=True)

    if not df_strips_combined.empty:
        print(f"\nStarting to map {len(df_strips_combined)} stripe cells onto the global scaffold...")
        strip_coords = df_strips_combined[['x', 'y']].values
        tree = cKDTree(strip_coords)
        master_coords = df_master[['x', 'y']].values

        distances, indices = tree.query(master_coords, k=1)

        is_match = distances <= MATCHING_RADIUS_MICRONS
        num_matches = np.sum(is_match)
        print(f"Successfully matched {num_matches} cells within {MATCHING_RADIUS_MICRONS}µm tolerance radius.")

        master_match_indices = df_master.index[is_match]
        strip_match_indices = indices[is_match]

        # Update master dataframe with matched data from strips
        df_master.loc[master_match_indices, COL_PHENOTYPE] = df_strips_combined.loc[
            strip_match_indices, COL_PHENOTYPE].values
        df_master.loc[master_match_indices, 'strip_id'] = df_strips_combined.loc[
            strip_match_indices, 'strip_id'].values

    # Parse phenotypes for the entire master dataframe
    final_df = parse_phenotypes(df_master, COL_PHENOTYPE, ALL_MARKERS)

    if len(final_df) != master_cell_count:
        print(
            f"Critical Warning: Final cell count ({len(final_df)}) does not match scaffold count ({master_cell_count})!")
    else:
        print("Validation Passed: Final cell count matches global scaffold.")

    final_df.reset_index(drop=True, inplace=True)
    final_df['cell_id'] = final_df.index

    pos_cols = [f"{m}_pos" for m in ALL_MARKERS if f"{m}_pos" in final_df.columns]
    output_cols = ['cell_id', 'x', 'y', 'strip_id', COL_PHENOTYPE] + pos_cols

    # Ensure all columns exist before slicing
    final_df = final_df[[c for c in output_cols if c in final_df.columns]]

    final_df.to_csv(OUTPUT_CSV, index=False)
    print(f"\n--- Preprocessing Complete! ---\nData saved to: {OUTPUT_CSV}")


if __name__ == "__main__":
    main()

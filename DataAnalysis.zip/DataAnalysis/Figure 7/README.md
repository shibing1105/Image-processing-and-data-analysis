# Code for: [Dual-Mode Microfluidic Immunostaining Device for Diagnostic Biomarkers Detection and Tumor Microenvironment Evaluation]

## Description

This repository contains the Python scripts used for the spatial analysis of cell phenotypes in [Your Sample Type, e.g., PCNSL] tissue, as described in our Science submission (Manuscript ID: XXXXX).

The analysis pipeline processes QuPath-derived cell data, aligns data from multiple multiplex "strips" to a master scaffold, performs global and strip-level spatial statistics (e.g., nearest-neighbor distance (NND), pair correlation function (PCF), co-localization permutations), and generates the summary visualizations used in the paper.

## Requirements

* Python 3.8+

* Required libraries are listed in requirements.txt. Install them using:

  ```
  pip install -r requirements.txt
  ```

## Directory Structure

To run the analysis, you must organize your files into the following structure. The results/ directory will be created automatically.

```
/repository_root/
├── data/
│   ├── Whole image.xlsx             <- Master scaffold file with all cell coordinates
│   ├── stripCD45.xlsx               <- Annotation file for strip 1
│   ├── stripVIM.xlsx                <- Annotation file for strip 2
│   └── ... (all 16 strip .xlsx files)
│
├── results/
│   └── (This directory is created automatically to store all outputs)
│
├── 1_data_preprocessing.py
├── 2_global_analysis.py
├── 3_global_analysis_advanced.py
├── 4_spatial_analysis_full.py
├── 5_visualization.py
├── 6_double_positive_cell_visualization.py
├── requirements.txt
└── README.md
```

## Execution Workflow

The scripts must be run sequentially, as each script depends on the output of the previous one.

1. 1_data_preprocessing.py

   * Input: Reads raw .xlsx files from the data/ directory.

   * Process: Aligns all cells from Whole image.xlsx and maps the phenotype annotations from each strip...xlsx file onto this master scaffold based on coordinate proximity.

   * Output: Saves the master data file all_cells_processed_master_scaffold.csv to the results/ directory.

2. 2_global_analysis.py

   * Input: results/all_cells_processed_master_scaffold.csv

   * Process: Generates global cell density (KDE) plots and a grid-based spatial correlation heatmap for key markers.

   * Output: Saves plots and data to results/global_analysis_output/.

3. 3_global_analysis_advanced.py

   * Input: results/all_cells_processed_master_scaffold.csv

   * Process: Performs advanced global analysis, including a spatial correlogram, tumor-centric Nearest Neighbor Distance (NND) distributions, and Pair Correlation Function (PCF) analysis.

   * Output: Saves plots and data to results/advanced_global_plots/.

4. 4_spatial_analysis_full.py

   * Input: results/all_cells_processed_master_scaffold.csv

   * Process: Runs the core analysis. For each diagnostic marker (strip), it performs permutation tests to determine spatial enrichment or avoidance relative to environmental markers. It also calculates neighborhood composition.

   * Output: Saves all statistical results to results/spatial_analysis_output_20um/stripe_summary_final.csv.

5. 5_visualization.py

   * Input: results/spatial_analysis_output_20um/stripe_summary_final.csv

   * Process: Creates the main summary visualizations from the statistical results, including the bubble heatmap and clustered heatmap.

   * Output: Saves final plots to results/comprehensive_plots_20um/.

6. 6_double_positive_cell_visualization.py

   * Input: results/all_cells_processed_master_scaffold.csv

   * Process: Performs a specific deep-dive analysis on double-positive (e.g., CD20+/Bcl-6+) cell populations, comparing their microenvironment to single-positive cells.

   * Output: Saves plots to results/deep_dive_composite_plots/.


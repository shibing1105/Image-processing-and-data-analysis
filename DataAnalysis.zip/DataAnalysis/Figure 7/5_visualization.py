import os
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
import numpy as np
import matplotlib.gridspec as gridspec
from matplotlib.patches import Patch
from matplotlib.colors import Normalize
from matplotlib.lines import Line2D

# --- Configuration ---
SCRIPT_DIR = os.path.abspath(os.path.dirname(__file__))
RESULTS_DIR = os.path.join(SCRIPT_DIR, "results")

# This script reads from the output of script 4
ANALYSIS_OUTPUT_DIR = os.path.join(RESULTS_DIR, "spatial_analysis_output_20um")
INPUT_CSV = os.path.join(ANALYSIS_OUTPUT_DIR, "stripe_summary_final.csv")
# It also reads the master file from script 1
GLOBAL_CELL_DATA_CSV = os.path.join(RESULTS_DIR, "all_cells_processed_master_scaffold.csv")
# And it produces its own output
OUTPUT_DIR = os.path.join(RESULTS_DIR, "comprehensive_plots_20um")
os.makedirs(OUTPUT_DIR, exist_ok=True)

ENV_MARKERS = ["CD20", "GFAP", "CD68", "CD8a", "CD4", "CD34"]
DIAG_MARKERS_MAP = {
    1: "CD45", 2: "VIM", 3: "CD20", 4: "CD79A", 5: "CD3", 6: "CD34",
    7: "CD5", 8: "Ki67", 9: "CD10", 10: "CD4", 11: "CD68", 12: "c-Myc",
    13: "CD8a", 14: "Bcl-6", 15: "MUM1", 16: "Bcl-2"
}
DIAG_MARKERS_ORDER = list(DIAG_MARKERS_MAP.values())
RADIUS = 20
COMPOSITION_COLORS = sns.color_palette("Paired", len(ENV_MARKERS))
COLOR_MAP = dict(zip(ENV_MARKERS, COMPOSITION_COLORS))
DIVERGING_PALETTE = "RdBu_r"


# --- Plotting Functions ---

def plot_bubble_heatmap(df):
    """Plot 1: Bubble Heatmap (Final legend-fix + robust version)"""
    print("1. Generating [Plot 1] Bubble Heatmap...")

    id_vars = ['marker']
    enrich_cols = [f"perm_internal_enrichment_{env}" for env in ENV_MARKERS]
    fdr_cols = [f"fdr_perm_internal_pval_{env}" for env in ENV_MARKERS]

    # Check if all required columns exist
    if not all(col in df.columns for col in enrich_cols + fdr_cols):
        print("  -> Warning: Not all enrichment/FDR columns found. Skipping bubble heatmap.")
        return

    enrich_df_long = df[id_vars + enrich_cols].melt(id_vars=id_vars, value_vars=enrich_cols, var_name='env_marker',
                                                    value_name='enrichment')
    enrich_df_long['env_marker'] = enrich_df_long['env_marker'].str.replace('perm_internal_enrichment_', '')
    fdr_df_long = df[id_vars + fdr_cols].melt(id_vars=id_vars, value_vars=fdr_cols, var_name='env_marker',
                                              value_name='fdr')
    fdr_df_long['env_marker'] = fdr_df_long['env_marker'].str.replace('fdr_perm_internal_pval_', '')

    plot_df = pd.merge(enrich_df_long, fdr_df_long, on=['marker', 'env_marker'])
    plot_df.dropna(subset=['enrichment', 'fdr'], inplace=True)

    if plot_df.empty:
        print("  -> Warning: No valid data for bubble heatmap.")
        return

    plot_df['neg_log10_fdr'] = -np.log10(plot_df['fdr'].clip(lower=1e-12))
    plot_df['log2_enrichment'] = np.log2(plot_df['enrichment'].clip(lower=1e-6))

    plot_df['marker'] = pd.Categorical(plot_df['marker'], categories=DIAG_MARKERS_ORDER, ordered=True)
    plot_df.to_csv(os.path.join(OUTPUT_DIR, "prism_data_bubble_plot.csv"), index=False)

    fig, ax = plt.subplots(figsize=(12, 10))
    # **[Dynamic Range Fix]**
    vmax = plot_df['log2_enrichment'].abs().quantile(0.98) if not plot_df.empty else 1.0
    vmax = max(vmax, 0.1)  # ensure it's not zero
    vmin = -vmax

    norm = Normalize(vmin=vmin, vmax=vmax)

    # **[Size Non-linear Mapping]**
    size_power = 1.5  # Adjust this power to change size differentiation
    plot_df['size_enhanced'] = plot_df['neg_log10_fdr'] ** size_power

    sns.scatterplot(
        data=plot_df, x='env_marker', y='marker',
        hue='log2_enrichment', size='size_enhanced',
        palette=DIVERGING_PALETTE, hue_norm=norm,
        sizes=(50, 800), edgecolor='black', linewidth=0.5,
        ax=ax, legend=False
    )
    plt.xticks(rotation=45, ha='right')
    plt.xlabel("Environmental Marker")
    plt.ylabel("Diagnostic Marker")
    plt.title(f"Bubble Heatmap of Spatial Interactions (r={RADIUS}um)", fontsize=16)

    # **[Legend Overhaul]** Manually create the desired legend
    legend_ax = fig.add_axes([0.95, 0.4, 0.2, 0.5])  # [left, bottom, width, height]
    legend_ax.axis('off')

    # --- Color Legend ---
    legend_ax.text(0, 1.0, 'Enrichment', transform=legend_ax.transAxes, fontsize=12, weight='bold')
    # Dynamically create 5 gradient labels
    enrich_labels = np.geomspace(max(1e-3, 2 ** vmin), 2 ** vmax, 5)
    log2_labels = np.log2(enrich_labels)
    colors = plt.get_cmap(DIVERGING_PALETTE)(norm(log2_labels))

    for i, (label, color) in enumerate(zip(enrich_labels, colors)):
        legend_ax.scatter(0, 0.9 - i * 0.1, s=150, color=color, edgecolor='black', clip_on=False)
        legend_ax.text(0.2, 0.9 - i * 0.1, f"{label:.1f}x", va='center', transform=legend_ax.transAxes)

    # --- Size Legend ---
    legend_ax.text(0, 0.3, 'Significance', transform=legend_ax.transAxes, fontsize=12, weight='bold')
    # Dynamically create 5 gradient sizes
    min_size_val, max_size_val = plot_df['neg_log10_fdr'].min(), plot_df['neg_log10_fdr'].max()
    size_values = np.linspace(min_size_val, max_size_val, 4)
    size_values = np.unique(np.round(size_values, 1))  # Avoid duplicates
    if len(size_values) == 0: size_values = [0]

    min_s, max_s = 50, 800  # from sizes=(50, 800)
    size_enhanced_min, size_enhanced_max = plot_df['size_enhanced'].min(), plot_df['size_enhanced'].max()

    def scale_size(val):
        if size_enhanced_max == size_enhanced_min: return min_s
        return min_s + (max_s - min_s) * (
                    (val ** size_power - size_enhanced_min) / (size_enhanced_max - size_enhanced_min))

    for i, val in enumerate(size_values):
        scaled_s = scale_size(val)
        if pd.isna(scaled_s): scaled_s = min_s
        legend_ax.scatter(0, 0.2 - i * 0.08, s=scaled_s, color='grey', edgecolor='black', clip_on=False)
        legend_ax.text(0.2, 0.2 - i * 0.08, f"{val:.1f}", va='center', transform=legend_ax.transAxes)
    legend_ax.text(0, 0.2 - len(size_values) * 0.08, "(-log10 FDR)", transform=legend_ax.transAxes, fontsize=9,
                   va='top')

    plt.savefig(os.path.join(OUTPUT_DIR, "scheme1_bubble_heatmap.png"), dpi=300, bbox_inches='tight')
    plt.savefig(os.path.join(OUTPUT_DIR, "scheme1_bubble_heatmap.svg"), bbox_inches='tight')
    plt.close()
    print("  -> Bubble heatmap PNG/SVG saved.")


def plot_clustered_heatmap(df):
    """Plot 2: Clustered Heatmap"""
    print("\n2. Generating [Plot 2] Clustered Heatmap...")
    enrich_cols = [f"perm_internal_enrichment_{env}" for env in ENV_MARKERS]
    if not all(col in df.columns for col in enrich_cols):
        print("  -> Warning: Not all enrichment columns found. Skipping clustered heatmap.")
        return

    plot_data = df.set_index('marker')[enrich_cols].dropna()
    plot_data.columns = ENV_MARKERS  # Rename columns

    if plot_data.empty or len(plot_data) < 2:
        print("  -> Warning: Not enough valid data for clustered heatmap.")
        return

    log2_plot_data = np.log2(plot_data.clip(lower=1e-6))

    # Determine dynamic range
    vmax = log2_plot_data.abs().max().max()
    vmax = max(vmax, 0.1)  # ensure not zero
    vmin = -vmax

    g = sns.clustermap(
        log2_plot_data, cmap=DIVERGING_PALETTE, center=0,
        vmin=vmin, vmax=vmax,
        annot=True, fmt=".2f",
        figsize=(12, 12), linewidths=.5
    )
    g.fig.suptitle(f"Clustered Heatmap of Log2(Enrichment) (r={RADIUS}um)", y=1.02)
    g.savefig(os.path.join(OUTPUT_DIR, "scheme2_clustered_heatmap.png"), dpi=300, bbox_inches='tight')
    g.savefig(os.path.join(OUTPUT_DIR, "scheme2_clustered_heatmap.svg"), bbox_inches='tight')
    plt.close()
    print("  -> Clustered heatmap PNG/SVG saved.")


def plot_complex_annotated_heatmap(df_summary, df_global):
    """Plot 3: Complex Annotated Heatmap (Pie chart annotation version)"""
    print("\n3. Generating [Plot 3] Complex Annotated Heatmap (Pie version)...")

    enrich_cols = [f"perm_internal_enrichment_{env}" for env in ENV_MARKERS]
    fdr_cols = [f"fdr_perm_internal_pval_{env}" for env in ENV_MARKERS]
    comp_cols = [f"composition_{env}" for env in ENV_MARKERS]

    if not all(col in df_summary.columns for col in enrich_cols + fdr_cols + comp_cols):
        print("  -> Warning: Missing required columns. Skipping complex annotated heatmap.")
        return

    enrich_df = df_summary.set_index('marker')[enrich_cols].reindex(DIAG_MARKERS_ORDER)
    enrich_df.columns = ENV_MARKERS
    fdr_df = df_summary.set_index('marker')[fdr_cols].reindex(DIAG_MARKERS_ORDER)
    fdr_df.columns = ENV_MARKERS

    size_df = -np.log10(fdr_df.fillna(1.0).clip(lower=1e-12))

    comp_df = df_summary.set_index('marker')[comp_cols].reindex(DIAG_MARKERS_ORDER)
    comp_df.columns = ENV_MARKERS

    global_abundance = pd.Series({m: df_global[f"{m}_pos"].sum() / len(df_global) for m in ENV_MARKERS}).to_frame(
        'abundance')

    fig = plt.figure(figsize=(18, 14))
    gs = gridspec.GridSpec(2, 2, width_ratios=[4, 1.5], height_ratios=[1.2, 4], wspace=0.05, hspace=0.05)
    ax_main = fig.add_subplot(gs[1, 0])
    ax_top = fig.add_subplot(gs[0, 0], sharex=ax_main)
    ax_right = fig.add_subplot(gs[1, 1], sharey=ax_main)

    y_coords, x_coords = np.arange(len(DIAG_MARKERS_ORDER)), np.arange(len(ENV_MARKERS))

    valid_enrich = enrich_df.stack().dropna()
    vmax = np.log2(valid_enrich.clip(lower=1e-6).quantile(0.98)) if not valid_enrich.empty else 1.0
    vmax = max(vmax, 0.1)
    vmin = -vmax
    norm = Normalize(vmin, vmax)

    for y_idx, diag_marker in enumerate(DIAG_MARKERS_ORDER):
        for x_idx, env_marker in enumerate(ENV_MARKERS):
            if diag_marker not in enrich_df.index: continue
            enrich = enrich_df.loc[diag_marker, env_marker]
            size = size_df.loc[diag_marker, env_marker]

            if pd.notna(enrich) and pd.notna(size) and size > -np.log10(0.05):  # Only plot significant
                log2_enrich = np.log2(enrich if enrich > 0 else 1e-6)
                color = plt.cm.RdBu_r(norm(log2_enrich))
                ax_main.scatter(x_idx, y_idx, s=(size ** 1.5) * 30, color=color, edgecolor='black', linewidth=0.5,
                                zorder=3)

    ax_main.set_yticks(y_coords)
    ax_main.set_yticklabels(DIAG_MARKERS_ORDER)
    ax_main.set_xticks(x_coords)
    ax_main.set_xticklabels([])
    ax_main.set_ylabel('Diagnostic Marker', fontsize=12)
    ax_main.grid(True, linestyle='--', alpha=0.3)
    ax_main.invert_yaxis()
    ax_main.set_xlim(x_coords[0] - 0.5, x_coords[-1] + 0.5)
    ax_main.set_ylim(y_coords[-1] + 0.5, y_coords[0] - 0.5)

    ax_top.bar(x_coords, global_abundance.loc[ENV_MARKERS, 'abundance'], color='darkgrey')
    ax_top.set_xticks(x_coords)
    ax_top.set_xticklabels(ENV_MARKERS, rotation=40, ha='left')
    ax_top.set_ylabel('Global\nAbundance', rotation=0, ha='right', va='center', fontsize=10)
    plt.setp(ax_top.get_xticklabels(), visible=True)
    ax_top.tick_params(axis='x', bottom=False, labelbottom=False, top=True, labeltop=True)

    ax_right.spines[['top', 'right', 'bottom', 'left']].set_visible(False)
    plt.setp(ax_right.get_yticklabels(), visible=False)
    ax_right.tick_params(axis='y', length=0)
    ax_right.set_xticks([])
    ax_right.set_xlabel('Composition')

    for i, diag_marker in enumerate(DIAG_MARKERS_ORDER):
        if diag_marker not in comp_df.index: continue
        comp_data = comp_df.loc[diag_marker].dropna()
        if comp_data.sum() > 0:
            pie_ax = ax_right.inset_axes([0, i - 0.45, 1, 0.9], transform=ax_right.get_yaxis_transform())
            pie_ax.pie(comp_data.values, colors=[COLOR_MAP[k] for k in comp_data.index],
                       wedgeprops={'linewidth': 0.5, 'edgecolor': 'white'})

    # ... (Manual legend would go here, similar to plot_bubble_heatmap) ...

    fig.suptitle("Complex Annotated Heatmap of Spatial Interactions", fontsize=20, y=0.99)
    plt.savefig(os.path.join(OUTPUT_DIR, "scheme3_complex_annotated_heatmap.png"), dpi=300, bbox_inches='tight')
    plt.savefig(os.path.join(OUTPUT_DIR, "scheme3_complex_annotated_heatmap.svg"), bbox_inches='tight')
    plt.close()
    print("  -> Complex annotated heatmap (Pie version) PNG/SVG saved.")


def main():
    print("--- Starting Comprehensive Visualization (Final legend & bug-fix version) ---")
    if not os.path.exists(INPUT_CSV):
        raise FileNotFoundError(f"Error: Statistics result file not found '{INPUT_CSV}'. Please run script 4 first.")

    summary_df = pd.read_csv(INPUT_CSV)

    try:
        global_df = pd.read_csv(GLOBAL_CELL_DATA_CSV)
    except FileNotFoundError:
        print(f"Warning: Global cell data file not found '{GLOBAL_CELL_DATA_CSV}'. Plot 3 will not run.")
        global_df = None

    plot_bubble_heatmap(summary_df)
    plot_clustered_heatmap(summary_df)
    if global_df is not None:
        plot_complex_annotated_heatmap(summary_df, global_df)
    else:
        print("\nSkipping [Plot 3] due to missing global cell data file.")

    print(f"\n--- All Visualizations and Exports Complete! ---\nCharts and Prism data saved to:\n{OUTPUT_DIR}")


if __name__ == "__main__":
    main()

# -*- coding: utf-8 -*-
"""
Part 1: Data Preprocessing, QC, and Normalization

- Reads raw data from the 3-sheet Excel file.
- Merges all samples into a single DataFrame.
- Adds boolean 'pos_Marker' columns based on 'Classification'.
- Performs per-sample, per-marker Z-score normalization to correct for
  technical variations (e.g., imaging power) between samples.
- Saves the processed master file.
- Calculates and saves a QC summary, including Signal-to-Background Ratio (SBR).
"""
import pandas as pd
import numpy as np
from pathlib import Path

# --- Configuration ---
# Input file (assumed to be in the same directory as the script)
INPUT_XLSX_PATH = '3tonsils.xlsx'
SHEET_NAMES = ['tonsil0827', 'tonsil0903', 'tonsil0909']
SAMPLE_NAMES = ['Tonsil_0827', 'Tonsil_0903', 'Tonsil_0909']

# List of markers for analysis
MARKER_NAMES = ['CD20', 'Ki67', 'CD68', 'CD8a', 'CD4', 'CD34']

# Map raw column names from Excel to standardized names
COLUMN_MAPPING = {
    'Classification': 'Classification',
    'Centroid X px': 'X',
    'Centroid Y px': 'Y',
    'Cell: CD20 mean': 'CD20',
    'Nucleus: Ki67 mean': 'Ki67',
    'Cell: CD68 mean': 'CD68',
    'Cell: CD8a mean': 'CD8a',
    'Cell: CD4 mean': 'CD4',
    'Cell: CD34 mean': 'CD34'
}

# Output directory
OUTPUT_DIR = Path('outputs/1_preprocessing_qc')
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)


def main():
    print("--- Part 1: Starting Data Preprocessing, QC, and SBR Calculation ---")

    # 1. Load and merge data
    all_dfs = []
    try:
        print(f"Loading data from '{INPUT_XLSX_PATH}'...")
        # Load all sheets at once
        xls = pd.read_excel(INPUT_XLSX_PATH, sheet_name=SHEET_NAMES, engine='openpyxl')
        for sheet_name, sample_name in zip(SHEET_NAMES, SAMPLE_NAMES):
            df = xls[sheet_name]
            df['Sample'] = sample_name
            all_dfs.append(df)
        print("Data loaded successfully.")
    except FileNotFoundError:
        print(f"ERROR: File not found '{INPUT_XLSX_PATH}'. Please place the file in the same directory as the script.")
        return
    except Exception as e:
        print(f"Error reading Excel file: {e}")
        return

    combined_df = pd.concat(all_dfs, ignore_index=True)

    # 2. Clean and standardize column names
    try:
        combined_df.rename(columns=COLUMN_MAPPING, inplace=True)
        final_cols_to_keep = ['Sample', 'Classification', 'X', 'Y'] + MARKER_NAMES
        combined_df = combined_df[final_cols_to_keep]
    except KeyError as e:
        print(f"ERROR: A required column is missing from the Excel file. Missing key: {e}")
        print("Please check that your Excel file contains all columns specified in COLUMN_MAPPING.")
        return

    # 3. Create 'pos_' boolean tag columns
    print("Creating positive/negative boolean tags for each marker...")

    def standardize_label(label):
        if pd.isna(label) or str(label).strip() == "":
            return "Unknown"
        return str(label).strip()

    combined_df['Classification'] = combined_df['Classification'].apply(standardize_label)
    for marker in MARKER_NAMES:
        combined_df[f'pos_{marker}'] = combined_df['Classification'].str.contains(marker, na=False)

    # 4. Z-Score Normalization (per-sample)
    print("Applying per-sample, per-marker Z-score normalization...")
    for marker in MARKER_NAMES:
        norm_col = f'{marker}_norm'
        # Group by sample, then apply z-score transformation
        combined_df[norm_col] = combined_df.groupby('Sample')[marker].transform(
            lambda x: (x - x.mean()) / x.std() if x.std() > 0 else 0
        )

    # 5. Calculate QC metrics (including SBR)
    print("Calculating QC metrics, including Signal-to-Background Ratio (SBR)...")
    qc_rows = []
    for sample in SAMPLE_NAMES:
        sample_df = combined_df[combined_df['Sample'] == sample]
        total_cells = len(sample_df)
        if total_cells == 0: continue

        for marker in MARKER_NAMES:
            pos_mask = sample_df[f'pos_{marker}'] == True
            neg_mask = sample_df[f'pos_{marker}'] == False

            positive_cells = sample_df[pos_mask]
            negative_cells = sample_df[neg_mask]

            mean_positive = positive_cells[marker].mean()
            mean_negative = negative_cells[marker].mean()

            sbr = mean_positive / mean_negative if mean_negative != 0 and not pd.isna(mean_negative) else np.nan
            n_pos = len(positive_cells)

            qc_rows.append({
                'Sample': sample,
                'Marker': marker,
                'Total_Cells_in_Sample': total_cells,
                'N_Positive_Cells': n_pos,
                'Positive_Rate (%)': (n_pos / total_cells) * 100 if total_cells > 0 else 0,
                'Mean_Intensity_Positive_Cells': mean_positive,
                'Mean_Intensity_Negative_Cells': mean_negative,
                'Signal_to_Background_Ratio': sbr,
            })

    qc_summary_df = pd.DataFrame(qc_rows)

    # 6. Save outputs
    processed_data_path = OUTPUT_DIR / 'all_samples_processed.csv'
    qc_summary_path = OUTPUT_DIR / 'qc_summary_table.csv'

    combined_df.to_csv(processed_data_path, index=False)
    print(f"\nSuccessfully saved processed data to: {processed_data_path}")

    qc_summary_df.to_csv(qc_summary_path, index=False)
    print(f"Successfully saved QC summary (with SBR) to: {qc_summary_path}")

    print("\nQC summary preview:")
    print(qc_summary_df.head().to_string())

    print("\n--- Part 1: Finished ---")


if __name__ == '__main__':
    main()

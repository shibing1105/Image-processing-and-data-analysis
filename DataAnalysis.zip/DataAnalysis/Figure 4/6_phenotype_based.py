# -*- coding: utf-8 -*-
"""
Part 6: Spatial Analysis (Method 2: Based on 'Phenotype' Labels)

Purpose:
Performs a parallel spatial consistency analysis using the
user-defined, threshold-based 'Phenotype' labels (e.g., 'CD20:Ki67').

This script serves as an orthogonal validation to the analysis in Part 5.
It reads the same master data file from Part 4 but uses the 'Phenotype'
column for cell identity.
"""
import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
from pathlib import Path
from sklearn.neighbors import NearestNeighbors
from sklearn.metrics.pairwise import cosine_similarity
import warnings

warnings.filterwarnings('ignore', category=FutureWarning)

# --- Configuration ---
# Input file (from Part 4)
MASTER_DATA_PATH = Path('outputs/4_spatial_prep/spatial_analysis_master_data.csv')

# The column to use for cell identity in this analysis
CELL_ID_COLUMN = 'Phenotype'

# Spatial analysis parameters
N_NEIGHBORS = 15
N_PERMUTATIONS = 100
TOP_N_INTERACTIONS = 5

# Output directory
OUTPUT_DIR = Path('outputs/6_spatial_analysis_phenotype')
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)


# --- Helper Functions (Identical to Part 5) ---
def jaccard_similarity(set1, set2):
    """Calculates the Jaccard similarity between two sets."""
    intersection = len(set1.intersection(set2))
    union = len(set1.union(set2))
    return intersection / union if union > 0 else 0


def get_core_circle(interaction_vector, top_n):
    """Gets the Top N attracted and repelled partners for a cell type."""
    self_interaction = interaction_vector.name
    interaction_vector = interaction_vector.drop(self_interaction, errors='ignore')
    attracted = set(interaction_vector.sort_values(ascending=False).head(top_n).index)
    repelled = set(interaction_vector.sort_values(ascending=True).head(top_n).index)
    return attracted, repelled


def calculate_enrichment(sample_df, all_unique_ids, cell_id_col, n_neighbors, n_perms):
    """Calculates the neighborhood enrichment matrix for a single sample."""
    coords = sample_df[['X', 'Y']].values
    labels = sample_df[cell_id_col].values
    print(f"  - Finding {n_neighbors} physical neighbors for {len(coords)} cells...")
    nn_model = NearestNeighbors(n_neighbors=n_neighbors + 1, algorithm='kd_tree').fit(coords)
    _, indices = nn_model.kneighbors(coords)
    neighbor_indices = indices[:, 1:]

    print("  - Calculating observed neighbor counts...")
    observed_counts = pd.crosstab(pd.Series(np.repeat(labels, n_neighbors)),
                                  pd.Series(labels[neighbor_indices.flatten()]))
    observed_counts = observed_counts.reindex(index=all_unique_ids, columns=all_unique_ids, fill_value=0)

    print(f"  - Performing {n_perms} permutations for expected counts...")
    perm_counts_list = []
    for _ in range(n_perms):
        perm_labels = np.random.permutation(labels)
        perm_counts = pd.crosstab(pd.Series(np.repeat(perm_labels, n_neighbors)),
                                  pd.Series(perm_labels[neighbor_indices.flatten()]))
        perm_counts = perm_counts.reindex(index=all_unique_ids, columns=all_unique_ids, fill_value=0)
        perm_counts_list.append(perm_counts)

    expected_counts = pd.concat(perm_counts_list).groupby(level=0).mean()
    enrichment_matrix = np.log2((observed_counts + 1) / (expected_counts + 1))
    return enrichment_matrix


# --- Main Script ---
def main():
    print(f"--- Part 6: Starting Spatial Analysis (Based on '{CELL_ID_COLUMN}') ---")

    try:
        df = pd.read_csv(MASTER_DATA_PATH)
    except FileNotFoundError:
        print(f"ERROR: Master data file not found: '{MASTER_DATA_PATH}'. Please run script 4 first.")
        return

    all_unique_ids = sorted(df[CELL_ID_COLUMN].unique())
    samples = df['Sample'].unique()
    enrichment_matrices = {}

    for sample in samples:
        print(f"\nAnalyzing neighborhood enrichment for sample: '{sample}'...")
        sample_df = df[df['Sample'] == sample].copy()
        enrichment_matrix = calculate_enrichment(sample_df, all_unique_ids, CELL_ID_COLUMN, N_NEIGHBORS, N_PERMUTATIONS)
        enrichment_matrices[sample] = enrichment_matrix
        enrichment_matrix.to_csv(OUTPUT_DIR / f'phenotype_enrichment_matrix_{sample}.csv')

        # Only plot heatmap if phenotypes are manageable
        if len(all_unique_ids) <= 50:
            plt.figure(figsize=(14, 12))
            sns.clustermap(enrichment_matrix, cmap='vlag', center=0, annot=False,
                           cbar_kws={'label': 'Log2(Observed/Expected)'})
            plt.suptitle(f'Neighborhood Enrichment (by Phenotype) - {sample}', y=1.02)
            plt.savefig(OUTPUT_DIR / f'phenotype_enrichment_heatmap_{sample}.png', dpi=300)
            plt.close()
            print(f"  - Saved enrichment matrix and heatmap for '{sample}'.")
        else:
            print(f"  - Too many phenotypes ({len(all_unique_ids)}). Skipping heatmap generation.")

    print("\nQuantifying spatial similarity across samples...")

    # --- Cosine Similarity Analysis ---
    cosine_results = []
    for i in range(len(samples)):
        for j in range(i + 1, len(samples)):
            s1, s2 = samples[i], samples[j]
            m1, m2 = enrichment_matrices[s1], enrichment_matrices[s2]

            similarities = [
                cosine_similarity(m1.loc[pid].values.reshape(1, -1), m2.loc[pid].values.reshape(1, -1))[0][0] for pid in
                all_unique_ids]

            cosine_results.append({
                'Sample_Pair': f"{s1}_vs_{s2}",
                'Mean_Cosine_Similarity': np.mean(similarities),
                'Std_Cosine_Similarity': np.std(similarities)
            })

    # --- Jaccard Index Analysis ---
    jaccard_results = []
    for i in range(len(samples)):
        for j in range(i + 1, len(samples)):
            s1, s2 = samples[i], samples[j]
            m1, m2 = enrichment_matrices[s1], enrichment_matrices[s2]

            attr_o, rep_o = [], []
            for pid in all_unique_ids:
                a1, r1 = get_core_circle(m1.loc[pid], TOP_N_INTERACTIONS)
                a2, r2 = get_core_circle(m2.loc[pid], TOP_N_INTERACTIONS)
                attr_o.append(jaccard_similarity(a1, a2))
                rep_o.append(jaccard_similarity(r1, r2))

            jaccard_results.append({
                'Sample_Pair': f"{s1}_vs_{s2}",
                'Mean_Jaccard_Attraction': np.mean(attr_o),
                'Mean_Jaccard_Repulsion': np.mean(rep_o)
            })

    # --- Generate Final Report ---
    with open(OUTPUT_DIR / 'phenotype_spatial_consistency_report.txt', 'w', encoding='utf-8') as f:
        f.write("Part 6: Spatial Consistency Report (Based on 'Phenotype')\n")
        f.write("=" * 60 + "\n")
        f.write("This report uses threshold-based 'Phenotypes' as cell identities.\n\n")
        f.write("--- Interaction Pattern Similarity (Cosine Similarity) ---\n")
        f.write(" - Mean_Cosine_Similarity: Avg. similarity of interaction patterns (closer to 1 is better).\n")
        f.write(" - Std_Cosine_Similarity: Stability of similarity across all clusters (lower is better).\n")
        f.write(pd.DataFrame(cosine_results).to_string(index=False) + "\n\n")
        f.write(f"--- 'Top {TOP_N_INTERACTIONS} Core Circle' Overlap (Jaccard Index) ---\n")
        f.write(" - Mean_Jaccard_Attraction: Avg. overlap of the Top 5 most attracted partners.\n")
        f.write(" - Mean_Jaccard_Repulsion: Avg. overlap of the Top 5 most repelled partners.\n")
        f.write(pd.DataFrame(jaccard_results).to_string(index=False) + "\n")

    print(f"Analysis report saved to '{OUTPUT_DIR}'")
    print("\n--- Part 6: Finished ---")


if __name__ == '__main__':
    main()

# -*- coding: utf-8 -*-
"""
Part 3 (Optional): Cluster Annotation Heatmap

- Loads the clustering results from Part 2.
- Selects a *single sample* (for clarity) to generate an annotation heatmap.
- Calculates the median normalized intensity for each marker in each cluster.
- Saves this as an Excel file with conditional color formatting,
  which is ideal for biological annotation of the clusters.
"""
import pandas as pd
import numpy as np
from pathlib import Path
import warnings

# Try to import openpyxl formatting tools
try:
    from openpyxl.formatting.rule import ColorScaleRule
except ImportError:
    ColorScaleRule = None
    print("Warning: 'openpyxl' not found or is missing components. Excel color formatting will be disabled.")
    print("You can install it with: pip install openpyxl")

# Suppress UserWarnings
warnings.filterwarnings("ignore", category=UserWarning)

# --- Configuration ---
# This is the sample that will be used to generate the heatmap.
# Change this if you want to inspect a different sample.
SAMPLE_TO_ANALYZE = 'Tonsil_0827'

# Input file (from Part 2)
INPUT_FILE = Path('outputs/2_clustering/phenograph_clustering_results.xlsx')

# Columns to use for the heatmap (normalized intensities)
MARKER_NAMES = ['CD20', 'Ki67', 'CD68', 'CD8a', 'CD4', 'CD34']
MARKER_COLS = [f'{m}_norm' for m in MARKER_NAMES]

# Output directory
OUTPUT_DIR = Path('outputs/3_cluster_annotation')
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
OUTPUT_EXCEL_FILE = OUTPUT_DIR / f'cluster_annotation_heatmap_{SAMPLE_TO_ANALYZE}.xlsx'
OUTPUT_CSV_FILE = OUTPUT_DIR / f'cluster_annotation_heatmap_{SAMPLE_TO_ANALYZE}.csv'


def main():
    print(f"--- Part 3 (Optional): Generating Cluster Annotation Heatmap for sample '{SAMPLE_TO_ANALYZE}' ---")

    # 1. Load data
    try:
        print(f"Loading clustering results from '{INPUT_FILE}'...")
        data = pd.read_excel(INPUT_FILE, engine='openpyxl')
    except FileNotFoundError:
        print(f"ERROR: Input file not found: '{INPUT_FILE}'. Please run script 2 first.")
        return
    except Exception as e:
        print(f"Error reading Excel file: {e}")
        return

    # 2. Filter for the selected sample
    sample_data = data[data['Sample'] == SAMPLE_TO_ANALYZE].copy()
    if sample_data.empty:
        print(f"ERROR: No data found for sample '{SAMPLE_TO_ANALYZE}'. Check the sample name.")
        return

    print(f"Filtered for sample '{SAMPLE_TO_ANALYZE}'. Found {len(sample_data)} cells.")

    # 3. Calculate median intensity for each cluster
    print("Calculating median normalized intensity for each cluster...")
    cluster_heatmap_data = sample_data.groupby('phenoGraph_clusters')[MARKER_COLS].median()

    # 4. Save results to Excel with conditional formatting
    print(f"Saving heatmap data to '{OUTPUT_EXCEL_FILE}'...")
    try:
        if ColorScaleRule is None:
            raise ImportError("Skipping Excel formatting.")

        with pd.ExcelWriter(OUTPUT_EXCEL_FILE, engine='openpyxl') as writer:
            cluster_heatmap_data.to_excel(writer, sheet_name='Cluster_Median_Intensity')

            workbook = writer.book
            worksheet = writer.sheets['Cluster_Median_Intensity']

            # Define a color scale rule (e.g., from light blue to red)
            rule = ColorScaleRule(start_type='min', start_color='63BE7B',  # Low (Greenish)
                                  mid_type='percentile', mid_value=50, mid_color='FFFFFF',  # Mid (White)
                                  end_type='max', end_color='F8696B')  # High (Reddish)

            # Apply the rule to each marker column
            num_rows = len(cluster_heatmap_data) + 1
            num_cols = len(MARKER_COLS)
            from openpyxl.utils import get_column_letter

            for i in range(num_cols):
                col_letter = get_column_letter(i + 2)  # +2 because cols are 1-indexed and col A is the cluster ID
                cell_range = f"{col_letter}2:{col_letter}{num_rows}"
                worksheet.conditional_formatting.add(cell_range, rule)

        print("Successfully saved formatted Excel heatmap.")

    except Exception as e:
        print(f"Warning: Could not save formatted Excel file ({e}).")
        print("Saving as a standard CSV file instead.")
        cluster_heatmap_data.to_csv(OUTPUT_CSV_FILE)
        print(f"Heatmap data saved to '{OUTPUT_CSV_FILE}'.")

    print("\n--- Part 3: Finished ---")


if __name__ == '__main__':
    main()

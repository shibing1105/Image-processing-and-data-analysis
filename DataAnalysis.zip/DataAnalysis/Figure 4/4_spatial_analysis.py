# -*- coding: utf-8 -*-
"""
Part 4: Create Master Data File for Spatial Analysis

Purpose:
This is an essential preparation step. It creates a single,
unified data file that contains ALL necessary information for the subsequent
parallel spatial analyses.

It merges data from two primary sources:
1.  'all_samples_processed.csv' (from Part 1): Provides the essential PHYSICAL 'X', 'Y'
    coordinates, 'Sample' ID, and the boolean 'pos_Marker' columns.
2.  'phenograph_clustering_results.xlsx' (from Part 2): Provides the data-driven 'Cluster' labels.

It also generates a new 'Phenotype' column based on the boolean 'pos_' labels,
creating a standardized "original label" for comparison.
"""
import pandas as pd
from pathlib import Path

# --- Configuration ---
# Input file 1: Contains physical coordinates and 'pos_' tags
PROCESSED_DATA_PATH = Path('outputs/1_preprocessing_qc/all_samples_processed.csv')
# Input file 2: Contains cluster labels
CLUSTER_DATA_PATH = Path('outputs/2_clustering/phenograph_clustering_results.xlsx')

# Markers to use for creating 'Phenotype' labels
MARKER_NAMES = ['CD20', 'Ki67', 'CD68', 'CD8a', 'CD4', 'CD34']
POS_COLS = [f'pos_{m}' for m in MARKER_NAMES]

# Output directory and file
OUTPUT_DIR = Path('outputs/4_spatial_prep')
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
MASTER_DATA_PATH = OUTPUT_DIR / 'spatial_analysis_master_data.csv'


# --- Main Script ---
def main():
    print("--- Part 4: Creating Master Data File for Spatial Analysis ---")

    try:
        print(f"Loading coordinate and 'pos' tag file: {PROCESSED_DATA_PATH}...")
        df_processed = pd.read_csv(PROCESSED_DATA_PATH)
        print("Load successful.")

        print(f"Loading cluster label file: {CLUSTER_DATA_PATH}...")
        # Only read the cluster column to save memory
        df_clusters = pd.read_excel(CLUSTER_DATA_PATH, usecols=['phenoGraph_clusters'], engine='openpyxl')
        print("Load successful.")

    except FileNotFoundError as e:
        print(f"ERROR: File not found - {e}. Please ensure scripts 1 and 2 have run successfully.")
        return

    if len(df_processed) != len(df_clusters):
        print("ERROR: Cell counts in processed file and cluster file do not match. Cannot merge.")
        print(f"Processed file rows: {len(df_processed)}")
        print(f"Cluster file rows: {len(df_clusters)}")
        print("Please check the integrity of the input files.")
        return

    # --- Step 1: Create 'Phenotype' column from 'pos_' tags ---
    print("Creating standardized 'Phenotype' column from 'pos_' tags...")

    def create_phenotype_label(row):
        positive_markers = [marker for marker, pos_col in zip(MARKER_NAMES, POS_COLS) if row[pos_col]]
        if not positive_markers:
            return "Unknown"
        # Sort alphabetically to ensure consistency (e.g., 'CD20:Ki67' not 'Ki67:CD20')
        return ":".join(sorted(positive_markers))

    df_processed['Phenotype'] = df_processed.apply(create_phenotype_label, axis=1)
    print("'Phenotype' column created successfully.")
    print("Example Phenotypes:")
    print(df_processed['Phenotype'].value_counts().head())

    # --- Step 2: Merge all required information ---
    print("Merging coordinates, sample, cluster, and phenotype info...")
    master_df = pd.DataFrame({
        'Sample': df_processed['Sample'],
        'X': df_processed['X'],
        'Y': df_processed['Y'],
        'Cluster': df_clusters['phenoGraph_clusters'],
        'Phenotype': df_processed['Phenotype']
    })

    # --- Save Master Data File ---
    master_df.to_csv(MASTER_DATA_PATH, index=False)
    print(f"\nSuccessfully created and saved master data file to:\n{MASTER_DATA_PATH}")
    print(f"Total cells: {len(master_df)}")
    print("\nMaster data preview:")
    print(master_df.head())
    print("\n--- Part 4: Finished ---")


if __name__ == '__main__':
    main()

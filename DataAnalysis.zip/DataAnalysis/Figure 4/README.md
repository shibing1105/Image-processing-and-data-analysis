# Quantitative Reproducibility Analysis of Multiplex Immunofluorescence Data

Python pipeline to assess reproducibility of a 6-plex mIF experiment on three serial human tonsil sections, as described in [Your Manuscript Title, Year, Journal]. Analysis covers marker expression, cell population composition, and spatial architecture consistency.

## 1. Dependencies

This pipeline requires Python 3.x. All required packages are listed in requirements.txt. Install them using pip:

```
pip install -r requirements.txt
```

## 2. Input Data

Place 3tonsils.xlsx (containing tonsil0827, tonsil0903, tonsil0909 worksheets with single-cell classification, coordinates, and intensities) in the same directory as the scripts.

## 3. Analysis Workflow

Run scripts numerically. Outputs are saved in corresponding sub-directories within outputs/.

### Step 1: Preprocessing & QC (1_Data_preprocessing_QC.py)

* Reads 3tonsils.xlsx, merges samples, performs Z-score normalization (per-sample), calculates SBR.

* Output: outputs/1_preprocessing_qc/ (includes all_samples_processed.csv)

### Step 2: Clustering (2_phenograph_3sections.py)

* Performs Phenograph clustering on combined normalized data from Step 1. Generates t-SNE plots.

* Output: outputs/2_clustering/ (includes phenograph_clustering_results.xlsx)

### Step 3 (Optional): Cluster Annotation (3_phenograph_single_section.py)

* Generates a marker expression heatmap (Excel) for clusters within a single sample to aid biological interpretation.

* Output: outputs/3_cluster_annotation/

### Step 4: Spatial Data Prep (4_spatial_analysis_prep.py)

* Merges coordinates (Step 1) and cluster labels (Step 2) into a master file for spatial analysis. Creates Phenotype labels for comparison.

* Output: outputs/4_spatial_prep/ (includes spatial_analysis_master_data.csv)

### Step 5 & 6: Spatial Consistency (Dual-Approach)

Parallel validation using different cell identity definitions. Both compute Neighborhood Enrichment based on physical coordinates and quantify similarity using Cosine Similarity and Jaccard Index.

* 5_spatial_analysis_by_cluster.py: Uses objective Cluster labels. Assesses reproducibility of the discovered cell ecosystem.

  * Output: outputs/5_spatial_analysis_cluster/

* 6_spatial_analysis_by_phenotype.py: Uses knowledge-based Phenotype labels. Provides orthogonal validation for classically-defined cell types.

  * Output: outputs/6_spatial_analysis_phenotype/


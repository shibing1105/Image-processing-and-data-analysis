# -*- coding: utf-8 -*-
"""
Part 2: Unsupervised Clustering (Phenograph) on All Samples

- Loads the preprocessed and normalized data from Part 1.
- Performs Phenograph clustering on the combined cell data from all 3 samples
  using the normalized marker intensities.
- Performs t-SNE dimensionality reduction.
- Saves the final data (original data + cluster labels + t-SNE coordinates)
  to an Excel file.
- Generates and saves t-SNE plots, colored by sample and cluster.
"""
import os
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.manifold import TSNE
import phenograph
import warnings
from pathlib import Path

# Suppress UserWarnings from Matplotlib (e.g., font cache)
warnings.filterwarnings("ignore", category=UserWarning)

# --- Configuration ---
# Input file (from Part 1)
INPUT_FILE = Path('outputs/1_preprocessing_qc/all_samples_processed.csv')

# Columns to use for clustering (normalized intensities)
MARKER_NAMES = ['CD20', 'Ki67', 'CD68', 'CD8a', 'CD4', 'CD34']
MARKER_COLS = [f'{m}_norm' for m in MARKER_NAMES]

# Phenograph parameters
K_NEIGHBORS = 30

# t-SNE parameters
TSNE_PERPLEXITY = 50
TSNE_RANDOM_STATE = 42

# Output directory
OUTPUT_DIR = Path('outputs/2_clustering')
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
OUTPUT_EXCEL_FILE = OUTPUT_DIR / 'phenograph_clustering_results.xlsx'
OUTPUT_TSNE_SAMPLE = OUTPUT_DIR / 'tsne_colored_by_sample.png'
OUTPUT_TSNE_CLUSTER = OUTPUT_DIR / 'tsne_colored_by_cluster.png'


def main():
    print("--- Part 2: Starting Unsupervised Clustering (Phenograph) ---")

    # 1. Load preprocessed data
    try:
        print(f"Loading preprocessed data from '{INPUT_FILE}'...")
        data = pd.read_csv(INPUT_FILE)
    except FileNotFoundError:
        print(f"ERROR: Input file not found: '{INPUT_FILE}'. Please run script 1 first.")
        return
    except Exception as e:
        print(f"Error reading CSV file: {e}")
        return

    # Prepare data for clustering
    data_for_clustering = data[MARKER_COLS].copy()

    # 2. Run Phenograph
    print(f"Running Phenograph with k={K_NEIGHBORS}...")
    communities, graph, Q = phenograph.cluster(data_for_clustering, k=K_NEIGHBORS)

    # Add cluster labels to the main DataFrame
    # Phenograph labels are 0-indexed, add 1 to make them 1-indexed
    data['phenoGraph_clusters'] = communities + 1

    print(f"Phenograph found {len(data['phenoGraph_clusters'].unique())} clusters. Modularity (Q) = {Q:.4f}")

    # 3. Run t-SNE
    print(f"Running t-SNE (perplexity={TSNE_PERPLEXITY})... This may take a few minutes.")
    tsne = TSNE(n_components=2, perplexity=TSNE_PERPLEXITY, random_state=TSNE_RANDOM_STATE, n_jobs=-1)
    tsne_results = tsne.fit_transform(data_for_clustering)

    data['tSNE1'] = tsne_results[:, 0]
    data['tSNE2'] = tsne_results[:, 1]
    print("t-SNE calculation complete.")

    # 4. Save clustering results to Excel
    print(f"Saving clustering results to '{OUTPUT_EXCEL_FILE}'...")
    try:
        data.to_excel(OUTPUT_EXCEL_FILE, index=False, engine='openpyxl')
        print("Successfully saved Excel file.")
    except Exception as e:
        print(f"Error saving Excel file: {e}")

    # 5. Plot t-SNE colored by Sample
    print("Generating t-SNE plot (colored by Sample)...")
    plt.figure(figsize=(12, 8))
    sns.scatterplot(x='tSNE1', y='tSNE2', hue='Sample', data=data, s=5, alpha=0.7, legend='full')
    plt.title("t-SNE Visualization (Colored by Sample)", fontsize=16)
    plt.xlabel("t-SNE 1", fontsize=12)
    plt.ylabel("t-SNE 2", fontsize=12)
    plt.legend(title='Sample', bbox_to_anchor=(1.05, 1), loc='upper left', markerscale=2)
    plt.grid(True, linestyle='--', alpha=0.5)
    plt.tight_layout(rect=[0, 0, 0.85, 1])
    plt.savefig(OUTPUT_TSNE_SAMPLE, dpi=300)
    plt.close()

    # 6. Plot t-SNE colored by Cluster
    print("Generating t-SNE plot (colored by Cluster)...")
    n_clusters = len(data['phenoGraph_clusters'].unique())
    plt.figure(figsize=(12, 8))
    sns.scatterplot(x='tSNE1', y='tSNE2', hue='phenoGraph_clusters', data=data, s=5, alpha=0.7,
                    palette=sns.color_palette("husl", n_clusters), legend='full')
    plt.title("t-SNE Visualization (Colored by Cluster)", fontsize=16)
    plt.xlabel("t-SNE 1", fontsize=12)
    plt.ylabel("t-SNE 2", fontsize=12)
    # Only show legend if clusters are manageable
    if n_clusters <= 50:
        plt.legend(title='Cluster', bbox_to_anchor=(1.05, 1), loc='upper left', markerscale=2)
        plt.tight_layout(rect=[0, 0, 0.85, 1])
    else:
        plt.legend().set_visible(False)
        plt.tight_layout()
    plt.savefig(OUTPUT_TSNE_CLUSTER, dpi=300)
    plt.close()

    print(f"Plots saved to '{OUTPUT_DIR}'")
    print("\n--- Part 2: Finished ---")


if __name__ == '__main__':
    main()

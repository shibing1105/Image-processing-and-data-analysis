# PCNSL Spatial Analysis Scripts

This repository contains Python scripts for processing and analyzing spatial biology data, originally used for a PCNSL study. The workflow includes PhenoGraph clustering, t-SNE visualization, and various spatial statistics (Ripley's K, Moran's I).

## Script Workflow

The scripts are numbered and intended to be run in the following order:

1. 1_phenograph_clustering.py: Loads raw data, performs normalization, runs PhenoGraph clustering and t-SNE reduction. (Generates output_phenograph_results.xlsx)

2. 2_cell_populations.py: Uses the results from script 1 to create an annotated t-SNE plot based on cell types.

3. 3_marker_intensity.py: Generates individual t-SNE plots colored by the intensity of specific markers.

4. 4_spatial_statistics.py: Calculates spatial statistics (Cross Ripley's K, Moran's I) for CD8+ and CD20+ cell interactions.

5. 5_monte_carlo.py: Performs a Monte Carlo simulation for Cross Ripley's K to test for spatial randomness (e.g., CD8+ vs. CD34+).

6. 6_clustermap_annotation.py: Creates an annotated heatmap showing the mean marker expression per cluster, along with cell counts.

## Data Structure

Scripts now use relative paths. Please organize your files as follows:

```
/Your-Project-Folder
|
|-- 1_phenograph_clustering.py
|-- 2_cell_populations.py
|-- 3_marker_intensity.py
|-- 4_spatial_statistics.py
|-- 5_monte_carlo.py
|-- 6_clustermap_annotation.py
|-- requirements.txt                (NEW: For installing dependencies)
|
|-- data_reorganized.xlsx           (Input for Script 1)
|-- data_reorganized_stitched.xlsx  (Input for Script 1)
|-- tonsils_analyzed.xlsx           (Input for Script 3)
|-- cluster_marker_averages.xlsx    (Input for Script 6)
|
|-- /spatial_analysis_data/         (Input directory for Scripts 4, 5)
|   |-- 1.xlsx                      (Vessel distance data for CD8+)
|   |-- 2.xlsx                      (CD8+ cell coordinates)
|   |-- 3.xlsx                      (CD20+ OR CD34+ coordinates, see Note)
|
|-- (Other output files will be generated here)
|-- (Folders like /marker_intensity_plots/ will be created)


```

## Requirements

This project requires several Python libraries. You can install all dependencies automatically by running:

```
pip install -r requirements.txt
```

Note: The requirements.txt file includes phenograph-community.

## Important Notes & Identified Issues

1. Critical Data Ambiguity (File 3.xlsx)

   There is a significant ambiguity in the original scripts regarding 3.xlsx:

   * 4_spatial_statistics.py loads spatial_analysis_data/3.xlsx and names the variable df_cd20 (implying CD20+ cells).

   * 5_monte_carlo.py loads the exact same file (spatial_analysis_data/3.xlsx) and names the variable data_cd34 (implying CD34+ cells).

   This is a contradiction. Please verify whether 3.xlsx contains CD20 or CD34 data and adjust the variable names in the scripts accordingly.

2. Hardcoded Column Indices

   1_phenograph_clustering.py assumes markers are in columns 1 through 6 (data_base.columns[1:7]). If your data structure differs, you must change this line.

3. Assumed File Headers

   Scripts 4 and 5 assume the input files in spatial_analysis_data/ (1, 2, 3.xlsx) have no header row. The data is expected to start on the first line.


import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy.spatial import cKDTree
from joblib import Parallel, delayed

# -----------------------------
# 1. File Paths and Data Loading
# -----------------------------
# Data is expected in a subdirectory named 'spatial_analysis_data'
DATA_DIR = "spatial_analysis_data"
# Results will be saved in 'monte_carlo_output'
OUTPUT_DIR = "monte_carlo_output"
os.makedirs(OUTPUT_DIR, exist_ok=True)

# *** NOTE ON DATA ***
# This script loads "3.xlsx" as CD34 data.
# Script "4_..." loads "3.xlsx" as CD20 data.
# Please verify this is correct.
FILE_CD8 = os.path.join(DATA_DIR, "2.xlsx")
FILE_CD34 = os.path.join(DATA_DIR, "3.xlsx")

try:
    # Files have no header; specify names manually (Label, x_px, y_px)
    data_cd8 = pd.read_excel(FILE_CD8, header=None, names=['Label', 'x_px', 'y_px'])
    data_cd34 = pd.read_excel(FILE_CD34, header=None, names=['Label', 'x_px', 'y_px'])
except FileNotFoundError as e:
    print(f"Error: Could not find data file. {e}")
    print(f"Please ensure files '2.xlsx' and '3.xlsx' exist in the '{DATA_DIR}' subfolder.")
    exit()

# -----------------------------
# 2. Unit Conversion
# -----------------------------
# Assumed conversion factor: 1 px = 0.5 μm (adjust as needed)
pixel_to_um = 0.5
points_cd8 = data_cd8[['x_px', 'y_px']].values * pixel_to_um
points_cd34 = data_cd34[['x_px', 'y_px']].values * pixel_to_um


# -----------------------------
# 3. Define Calculation Functions (KD-Tree based)
# -----------------------------
def compute_cross_K(points1, points2, radii, area):
    """
    Compute cross Ripley's K function:
      K(r) = (Area / (n1 * n2)) * [count of pairs with distance <= r]
    Use cKDTree to query neighbors efficiently, avoiding large distance matrix.
    """
    n1 = len(points1)
    n2 = len(points2)
    if n1 == 0 or n2 == 0:
        return np.zeros_like(radii)

    tree = cKDTree(points2)
    K_vals = []
    for r in radii:
        # For each point in points1, query all points in points2 within radius r
        counts = tree.query_ball_point(points1, r)
        total_pairs = sum(len(lst) for lst in counts)
        K_vals.append(area / (n1 * n2) * total_pairs)
    return np.array(K_vals)


def calculate_roi(points1, points2):
    """
    Calculate ROI boundaries and area based on the extent of both point sets
    """
    combined = np.vstack([points1, points2])
    x_min, x_max = combined[:, 0].min(), combined[:, 0].max()
    y_min, y_max = combined[:, 1].min(), combined[:, 1].max()
    area = (x_max - x_min) * (y_max - y_min)
    return x_min, x_max, y_min, y_max, area


# -----------------------------
# 4. Parameters and Observed Value Calculation
# -----------------------------
max_radius = 100  # μm
num_radii = 50
radii = np.linspace(0, max_radius, num_radii)

x_min, x_max, y_min, y_max, area = calculate_roi(points_cd8, points_cd34)
print(f"ROI: x ∈ [{x_min:.2f}, {x_max:.2f}], y ∈ [{y_min:.2f}, {y_max:.2f}], area = {area:.2f} μm²")

observed_crossK = compute_cross_K(points_cd8, points_cd34, radii, area)
theoretical_K = np.pi * radii ** 2  # Theoretical K under CSR

# -----------------------------
# 5. Monte Carlo Simulation (Parallelized)
# -----------------------------
N_sim = 200  # Number of simulations (adjust based on resources)
n_cd8 = len(points_cd8)
n_cd34 = len(points_cd34)


def simulate_crossK():
    # Generate uniformly random points within the ROI
    sim_cd8 = np.column_stack((
        np.random.uniform(x_min, x_max, n_cd8),
        np.random.uniform(y_min, y_max, n_cd8)
    ))
    sim_cd34 = np.column_stack((
        np.random.uniform(x_min, x_max, n_cd34),
        np.random.uniform(y_min, y_max, n_cd34)
    ))
    return compute_cross_K(sim_cd8, sim_cd34, radii, area)


# Use joblib for parallel simulation
# n_jobs=-1 uses all available cores
simulated_crossK_list = Parallel(n_jobs=-1)(delayed(simulate_crossK)() for _ in range(N_sim))
simulated_crossK = np.vstack(simulated_crossK_list)
print("Simulation results shape:", simulated_crossK.shape)

# Calculate 95% simulation envelope and mean curve
lower_envelope = np.percentile(simulated_crossK, 2.5, axis=0)
upper_envelope = np.percentile(simulated_crossK, 97.5, axis=0)
mean_simulated = np.mean(simulated_crossK, axis=0)
print("lower_envelope shape:", lower_envelope.shape)
print("upper_envelope shape:", upper_envelope.shape)

# -----------------------------
# 6. Global Statistical Test
# -----------------------------
delta_r = radii[1] - radii[0]
T_observed = np.sum((observed_crossK - mean_simulated) ** 2) * delta_r
T_sim = np.sum((simulated_crossK - mean_simulated) ** 2, axis=1) * delta_r
p_value_T = (np.sum(T_sim >= T_observed) + 1) / (N_sim + 1)

Tmax_observed = np.max(np.abs(observed_crossK - mean_simulated))
Tmax_sim = np.max(np.abs(simulated_crossK - mean_simulated), axis=1)
p_value_Tmax = (np.sum(Tmax_sim >= Tmax_observed) + 1) / (N_sim + 1)

print(f"\nGlobal integral squared difference T_observed = {T_observed:.4f}, p-value = {p_value_T:.4f}")
print(f"Global max deviation Tmax_observed = {Tmax_observed:.4f}, p-value = {p_value_Tmax:.4f}")

# -----------------------------
# 7. Plotting and SVG Export
# -----------------------------
plt.figure(figsize=(10, 6))
plt.plot(radii, observed_crossK, 'r-', lw=2, label="Observed cross K")
plt.plot(radii, theoretical_K, 'k--', lw=2, label="Theoretical CSR: πr²")
plt.fill_between(radii, lower_envelope, upper_envelope,
                 where=np.ones_like(radii, dtype=bool),
                 color='gray', alpha=0.5,
                 label="Monte Carlo 95% Envelope")
plt.xlabel("Radius (μm)")
plt.ylabel("K(r)")
plt.title("Cross Ripley's K Function with Monte Carlo Envelope")
plt.legend()
plt.grid(True)

# Save plot as SVG
plot_file = os.path.join(OUTPUT_DIR, "Cross_RipleysK_Result.svg")
plt.savefig(plot_file, format="svg")
print(f"Plot saved to {plot_file}")
plt.show()

# -----------------------------
# 8. Export Results Data
# -----------------------------
results_df = pd.DataFrame({
    'Radius (μm)': radii,
    'Observed_crossK': observed_crossK,
    'Mean_simulated': mean_simulated,
    'Lower_envelope': lower_envelope,
    'Upper_envelope': upper_envelope,
    'Theoretical_K': theoretical_K
})
csv_file = os.path.join(OUTPUT_DIR, "Cross_RipleysK_Results.csv")
results_df.to_csv(csv_file, index=False)
print(f"Results saved to {csv_file}")

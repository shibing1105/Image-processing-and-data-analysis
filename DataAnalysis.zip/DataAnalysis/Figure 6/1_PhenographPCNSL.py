import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.manifold import TSNE
from sklearn.preprocessing import MinMaxScaler
import phenograph
import os

# --- Configuration ---
# Input files (assumed to be in the same directory as the script)
FILE_BASE = 'data_reorganized.xlsx'
FILE_STITCHED = 'data_reorganized_stitched.xlsx'

# Output files
OUTPUT_NORMALIZED_BASE = 'output_normalized_base.xlsx'
OUTPUT_NORMALIZED_STITCHED = 'output_normalized_stitched.xlsx'
OUTPUT_TSNE_PLOT = 'output_tSNE_PhenoGraph_Clustering.png'
OUTPUT_HEATMAP_PLOT = 'output_Clustering_Heatmap.png'
OUTPUT_FINAL_DATA = 'output_phenograph_results.xlsx'


# ---------------------

def main():
    # 1. Load two data files
    # Check if files exist
    if not os.path.exists(FILE_BASE) or not os.path.exists(FILE_STITCHED):
        print(f"Error: Input file(s) not found. Please place {FILE_BASE} and {FILE_STITCHED} in the script directory.")
        return

    data_base = pd.read_excel(FILE_BASE, sheet_name='Sheet1')
    data_stitched = pd.read_excel(FILE_STITCHED, sheet_name='Sheet1')

    # 2. Extract marker data (assuming columns 1-6 are markers, adjust indices if necessary)
    # Python indexing [1:7] means columns at index 1, 2, 3, 4, 5, 6 (7 columns total, skipping the first)
    markers = data_base.columns[1:7]  # Assuming both files have the same format
    marker_base = data_base[markers].fillna(0)
    marker_stitched = data_stitched[markers].fillna(0)

    # 3. Use the base data to calculate normalization parameters (MinMax scaling)
    scaler = MinMaxScaler()
    # Fit and transform the base data
    marker_base_scaled = pd.DataFrame(scaler.fit_transform(marker_base), columns=markers)
    # Use the same scaler to transform the stitched data
    marker_stitched_scaled = pd.DataFrame(scaler.transform(marker_stitched), columns=markers)

    # Assign normalized data back to the original dataframe (to keep other info)
    data_base[markers] = marker_base_scaled
    data_stitched[markers] = marker_stitched_scaled

    # Optional: Save normalized data
    data_base.to_excel(OUTPUT_NORMALIZED_BASE, index=False)
    data_stitched.to_excel(OUTPUT_NORMALIZED_STITCHED, index=False)
    print(f"Normalized data saved to {OUTPUT_NORMALIZED_BASE} and {OUTPUT_NORMALIZED_STITCHED}.")

    # 4. Merge the two datasets
    data_merged = pd.concat([data_base, data_stitched], ignore_index=True)

    # 5. Perform PhenoGraph clustering
    # Convert marker data to a list-of-lists, ensuring format is valid
    marker_list = data_merged[markers].fillna(0).values.tolist()
    communities, graph, Q = phenograph.cluster(marker_list, k=30)
    data_merged['Cluster'] = communities

    # 6. Barnes-Hut t-SNE dimensionality reduction
    tsne = TSNE(n_components=2, method='barnes_hut', random_state=42)
    tsne_result = tsne.fit_transform(data_merged[markers].fillna(0))
    data_merged['tSNE1'] = tsne_result[:, 0]
    data_merged['tSNE2'] = tsne_result[:, 1]

    # 7. Plot t-SNE clustering results
    plt.figure(figsize=(10, 6))
    sns.scatterplot(x='tSNE1', y='tSNE2', hue='Cluster', data=data_merged, palette='viridis', s=5)
    plt.title("PhenoGraph Clustering with Barnes-Hut t-SNE")
    plt.xlabel("tSNE1")
    plt.ylabel("tSNE2")
    plt.legend(title='Cluster')
    plt.grid(True, linestyle='--', alpha=0.5)
    plt.tight_layout()
    plt.savefig(OUTPUT_TSNE_PLOT)
    plt.show()

    # 8. Plot clustering heatmap (hierarchical clustering)
    clustermap = sns.clustermap(data_merged[markers].fillna(0), method='ward', cmap='viridis', figsize=(10, 10))
    # Save the clustermap
    clustermap.savefig(OUTPUT_HEATMAP_PLOT)
    plt.title("Clustering Heatmap")
    plt.show()

    # 9. Save data with clustering and dimensionality reduction results to Excel
    data_merged.to_excel(OUTPUT_FINAL_DATA, index=False)
    print(f"Analysis complete. Results saved to: {OUTPUT_FINAL_DATA}")


if __name__ == '__main__':
    main()

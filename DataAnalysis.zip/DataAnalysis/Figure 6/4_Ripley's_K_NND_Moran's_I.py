import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from astropy.stats import RipleysKEstimator
from scipy.stats import bootstrap, pearsonr, spearmanr
from scipy.spatial.distance import cdist
from sklearn.neighbors import KernelDensity
import statsmodels.api as sm

# Packages for spatial autocorrelation
from libpysal.weights import KNN
import esda
from splot.esda import moran_scatterplot

# Note: Removed Chinese font setting (plt.rcParams['font.family'] = 'SimSun')
# Ensure you have a default font that supports English characters.

# --------------------------
# --- User Parameters ---
# --------------------------
px_to_um = 475 / 512      # Pixel to micrometer conversion ratio
threshold_um = 50         # Perivascular threshold (unit: μm)
radii = np.linspace(0, 100, 50)  # Analysis radii range (unit: μm)

# --------------------------
# --- Input/Output Directories ---
# --------------------------
# Data is expected in a subdirectory named 'spatial_analysis_data'
DATA_DIR = "spatial_analysis_data"
# Results will be saved in a subdirectory named 'spatial_analysis_output'
OUTPUT_DIR = "spatial_analysis_output"
if not os.path.exists(OUTPUT_DIR):
    os.makedirs(OUTPUT_DIR)

# --------------------------
# --- Data Loading ---
# --------------------------
# Assuming file structure:
#   - 2.xlsx: CD8a+ cell data, columns: Label, x_px, y_px
#   - 3.xlsx: CD20+ cell data, columns: Label, x_px, y_px
#   - 1.xlsx: Vessel distance data (for CD8a+ cells), use second column
file_cd8 = os.path.join(DATA_DIR, "2.xlsx")
file_cd20 = os.path.join(DATA_DIR, "3.xlsx")
file_distance = os.path.join(DATA_DIR, "1.xlsx")

try:
    df_cd8 = pd.read_excel(file_cd8, header=None, names=["Label", "x_px", "y_px"])
    df_cd20 = pd.read_excel(file_cd20, header=None, names=["Label", "x_px", "y_px"])
    df_distance = pd.read_excel(file_distance, usecols=[1], header=None, names=["Distance_px"])
except FileNotFoundError as e:
    print(f"Error: Could not find data file. {e}")
    print(f"Please ensure files '1.xlsx', '2.xlsx', and '3.xlsx' exist in the '{DATA_DIR}' subfolder.")
    exit()


# Merge CD8a+ data with vessel distance data (ensure same row count)
df_cd8 = pd.concat([df_cd8.reset_index(drop=True),
                    df_distance.reset_index(drop=True)], axis=1)
df_cd8["Distance_px"] = df_cd8["Distance_px"].fillna(0)

# --------------------------
# --- Unit Conversion: px -> μm ---
# --------------------------
df_cd8["Distance_um"] = df_cd8["Distance_px"] * px_to_um
df_cd8[["x_um", "y_um"]] = df_cd8[["x_px", "y_px"]] * px_to_um
df_cd20[["x_um", "y_um"]] = df_cd20[["x_px", "y_px"]] * px_to_um

# --------------------------
# --- Visualize Raw Spatial Distribution ---
# --------------------------
cd8_coords = df_cd8[["x_um", "y_um"]].values
cd20_coords = df_cd20[["x_um", "y_um"]].values

plt.figure(figsize=(8,8))
plt.scatter(cd8_coords[:,0], cd8_coords[:,1], c='blue', s=1, label="CD8+")
plt.scatter(cd20_coords[:,0], cd20_coords[:,1], c='red', marker='^', s=1, label="CD20+")
plt.xlabel("X (μm)")
plt.ylabel("Y (μm)")
plt.title("Spatial Distribution of CD8+ and CD20+ Cells")
plt.legend()
plt.tight_layout()
plt.savefig(os.path.join(OUTPUT_DIR, "spatial_distribution.svg"), format="svg")
plt.show()

# --------------------------
# --- Cross Ripley's K Analysis (CD8+ vs CD20+) ---
# --------------------------
def compute_cross_K(points1, points2, radii, area):
    """
    Compute cross Ripley's K function:
      K(r) = (Area / (n1 * n2)) * [count of pairs with distance <= r]
    """
    n1 = len(points1)
    n2 = len(points2)
    if n1 == 0 or n2 == 0:
        return np.zeros_like(radii)
    dmat = cdist(points1, points2)
    K = np.array([area/(n1*n2) * np.sum(dmat <= r) for r in radii])
    return K

def calculate_cross_ripley_k(cd8_points, cd20_points):
    """Calculate cross Ripley's K for CD8+ vs CD20+"""
    combined_coords = np.vstack([cd8_points, cd20_points])
    x_min = combined_coords[:,0].min()
    x_max = combined_coords[:,0].max()
    y_min = combined_coords[:,1].min()
    y_max = combined_coords[:,1].max()
    area = (x_max - x_min) * (y_max - y_min)
    K = compute_cross_K(cd8_points, cd20_points, radii, area)
    return K, radii, area

k_values, radii, roi_area_cross = calculate_cross_ripley_k(cd8_coords, cd20_coords)

# --------------------------
# --- Export Cross Ripley's K Data ---
# --------------------------
df_crossK = pd.DataFrame({
    "radii": radii,
    "cross_K": k_values,
    "expected_K": np.pi * radii**2
})
df_crossK.to_csv(os.path.join(OUTPUT_DIR, "cross_ripleyK_data.csv"), index=False)

# --------------------------
# --- Plot Cross Ripley's K ---
# --------------------------
plt.figure(figsize=(10, 6))
plt.plot(radii, k_values, lw=2, label="CD8-CD20 Cross K")
plt.plot(radii, np.pi * radii**2, "k--", label="Random Distribution (CSR)")
plt.xlabel("Radius (μm)", fontsize=12)
plt.ylabel("Cross Ripley's K Value", fontsize=12)
plt.legend()
plt.grid(True, alpha=0.3)
plt.tight_layout()
plt.savefig(os.path.join(OUTPUT_DIR, "cross_ripleyK_plot.svg"), format="svg")
plt.show()

# --------------------------
# --- Perivascular Infiltration Analysis ---
# --------------------------
df_cd8["Perivascular"] = df_cd8["Distance_um"] <= threshold_um
pv_ratio = df_cd8["Perivascular"].mean()
print(f"\nPerivascular infiltration ratio (≤{threshold_um}μm): {pv_ratio:.1%}")

plt.figure(figsize=(8, 5))
sns.histplot(df_cd8["Distance_um"], bins=30, kde=True)
plt.axvline(threshold_um, color="r", linestyle="--", label=f"Threshold {threshold_um}μm")
plt.xlabel("Distance to nearest CD20+ cell (μm)")
plt.ylabel("CD8+ Cell Count")
plt.legend()
plt.title("CD8+ Cell Proximity to Vessels Distribution")
plt.tight_layout()
plt.savefig(os.path.join(OUTPUT_DIR, "cd8_distance_histogram.svg"), format="svg")
plt.show()

# --------------------------
# --- Spatial Autocorrelation (Moran's I) ---
# --------------------------
w = KNN(cd8_coords, k=5)
moran = esda.Moran(df_cd8["Distance_um"].values, w)
print(f"Moran's I: {moran.I:.4f}, p-value: {moran.p_sim:.4f}")

fig, ax = moran_scatterplot(moran)
plt.title("Moran Scatter Plot")
plt.tight_layout()
plt.savefig(os.path.join(OUTPUT_DIR, "moran_scatterplot.svg"), format="svg", dpi=100, bbox_inches="tight")
plt.show()

# --------------------------
# --- KDE for Local Vessel Density (for CD20+ cells) ---
# --------------------------
kde = KernelDensity(bandwidth=50, kernel="gaussian").fit(df_cd20[["x_um", "y_um"]].values)
log_density = kde.score_samples(df_cd8[["x_um", "y_um"]].values)
df_cd8["CD20_density_kde"] = np.exp(log_density)

print(df_cd8.head())
print(df_cd8.columns)

# --------------------------
# --- Correlation Analysis (CD8+ distance vs. local CD20 density) ---
# --------------------------
pearson_corr, pearson_p = pearsonr(df_cd8["Distance_um"], df_cd8["CD20_density_kde"])
spearman_corr, spearman_p = spearmanr(df_cd8["Distance_um"], df_cd8["CD20_density_kde"])
print(f"Pearson correlation: r = {pearson_corr:.4f}, p = {pearson_p:.4f}")
print(f"Spearman correlation: r = {spearman_corr:.4f}, p = {spearman_p:.4f}")

# --------------------------
# --- KDE Density Visualization & Grid Export ---
# --------------------------
x_grid = np.linspace(cd8_coords[:,0].min(), cd8_coords[:,0].max(), 100)
y_grid = np.linspace(cd8_coords[:,1].min(), cd8_coords[:,1].max(), 100)
X, Y = np.meshgrid(x_grid, y_grid)
grid_points = np.column_stack([X.ravel(), Y.ravel()])

kde_vals = kde.score_samples(grid_points)
density_grid = np.exp(kde_vals).reshape(X.shape)

df_kde = pd.DataFrame({
    "X": X.ravel(),
    "Y": Y.ravel(),
    "density": density_grid.ravel()
})
df_kde.to_csv(os.path.join(OUTPUT_DIR, "kde_density_data.csv"), index=False)

g = sns.jointplot(x="Distance_um", y="CD20_density_kde", data=df_cd8, kind="hex")
g.fig.suptitle("Joint Distribution of CD8+ Distance and Local CD20 Density")
g.fig.tight_layout()
g.fig.subplots_adjust(top=0.95)
plt.savefig(os.path.join(OUTPUT_DIR, "distance_density_jointplot.svg"), format="svg")
plt.show()

# --------------------------
# --- LOWESS Fit & Export Fit Data ---
# --------------------------
lowess_result = sm.nonparametric.lowess(df_cd8["CD20_density_kde"], df_cd8["Distance_um"], frac=0.3)
df_lowess = pd.DataFrame(lowess_result, columns=["Distance_um", "Lowess_CD20_density"])
df_lowess.to_csv(os.path.join(OUTPUT_DIR, "lowess_fitted_curve.csv"), index=False)

plt.figure(figsize=(8, 6))
sns.scatterplot(x="Distance_um", y="CD20_density_kde", data=df_cd8, alpha=0.5, label="Data Points")
sns.regplot(x="Distance_um", y="CD20_density_kde", data=df_cd8, scatter=False, lowess=True,
            label="LOWESS Fit", color="red")
plt.xlabel("Distance to nearest CD20+ cell (μm)")
plt.ylabel("Local CD20 Density (cells/μm²)")
plt.title("Correlation of CD8+ Distance and Local Vessel Density")
plt.legend()
plt.tight_layout()
plt.savefig(os.path.join(OUTPUT_DIR, "distance_density_scatterplot_improved.svg"), format="svg")
plt.show()

# --------------------------
# --- Export All Analysis Data and Summary ---
# --------------------------
df_cd8.to_csv(os.path.join(OUTPUT_DIR, "cd8_analysis_data.csv"), index=False)

summary_file = os.path.join(OUTPUT_DIR, "analysis_summary_results.txt")
with open(summary_file, "w", encoding="utf-8") as f:
    f.write(f"--- Analysis Summary ---\n")
    f.write(f"Perivascular infiltration ratio (≤{threshold_um}μm): {pv_ratio:.1%}\n")
    f.write(f"Moran's I: {moran.I:.4f}, p-value: {moran.p_sim:.4f}\n")
    f.write(f"Pearson correlation (Distance vs Density): r = {pearson_corr:.4f}, p = {pearson_p:.4f}\n")
    f.write(f"Spearman correlation (Distance vs Density): r = {spearman_corr:.4f}, p = {spearman_p:.4f}\n")

print(f"All analysis complete. Results saved to {OUTPUT_DIR}")

import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from matplotlib.font_manager import FontProperties
import textwrap
import os

# --- Configuration ---
# This script depends on the output of 1_phenograph_clustering.py
INPUT_FILE = 'output_phenograph_results.xlsx'
OUTPUT_PLOT = 'output_tsne_cell_populations.eps'
# ---------------------

# Load Excel file
if not os.path.exists(INPUT_FILE):
    print(f"Error: Input file not found. Please run script 1 first to generate {INPUT_FILE}.")
    exit()

data = pd.read_excel(INPUT_FILE)

# Define mapping from cluster labels to cell population names
cluster_to_cell_group = {
    0: 'Cytotoxic T cells',
    1: 'Unknown',
    2: 'Neoplastic B cells',
    3: 'Cytotoxic T cells',
    4: 'Astrocytes',
    5: 'Astrocytes',
    6: 'Cytotoxic T cells',
    7: 'Unknown',
    8: 'Unknown',
    9: 'Neoplastic B cells',
    10: 'Cytotoxic T cells',
    11: 'Astrocytes',
    12: 'Cytotoxic T cells',
    13: 'Tumor-associated macrophages',
    14: 'Cytotoxic T cells',
    15: 'Neoplastic B cells',
    16: 'Unknown',
    17: 'Tumor-associated macrophages',
    18: 'Tumor-associated macrophages',
    19: 'Helper T cells',
    20: 'Neoplastic B cells',
    21: 'Endothelial Cells',
    22: 'Astrocytes',
    23: 'Tumor-associated macrophages',
    24: 'Unknown',
    25: 'Unknown',
    26: 'Unknown',
    27: 'Tumor-associated macrophages',
    28: 'Endothelial Cells',
    29: 'Neoplastic B cells',
    30: 'Astrocytes',
    31: 'Helper T cells',
    32: 'Unknown',
    33: 'Tumor-associated macrophages',
}

# Map cluster labels to cell group names
data['CellGroup'] = data['Cluster'].map(cluster_to_cell_group)

# Count unique cell groups
cell_groups = data['CellGroup'].unique()
print(f"Found {len(cell_groups)} cell groups:", cell_groups)

# Define a color palette (CNS journal style): colorblind-safe, good contrast.
# 'Unknown' is light gray; others are distinct colors.
custom_palette = {
    'Unknown': '#CCCCCC',                     # Light Gray
    'Cytotoxic T cells': '#D26070',           # Red
    'Neoplastic B cells': '#ECBDCA',          # Orange
    'Helper T cells': '#EFCE70',              # Pink (Yellowish)
    'Tumor-associated macrophages': '#AFD19F',# Green
    'Astrocytes': '#AAD3E7',                  # Purple
    'Endothelial Cells': '#606AAF',           # Blue
}


# Assign colors to each cell group
cell_group_colors = {group: custom_palette[group] for group in cell_groups if group in custom_palette}
# Add fallbacks for any groups not in the palette (though all defined ones are)
for group in cell_groups:
    if group not in cell_group_colors:
        cell_group_colors[group] = '#000000' # Default to black if undefined

# Plot t-SNE
fig, ax = plt.subplots(figsize=(10, 5))

sns.scatterplot(
    x='tSNE1',
    y='tSNE2',
    hue='CellGroup',
    data=data,
    palette=cell_group_colors,
    s=5,
    alpha=0.5,
    edgecolors='none',
    ax=ax
)

# Set axis labels
plt.xlabel('t-SNE 1', fontsize=10, fontweight='bold', family='Arial')
plt.ylabel('t-SNE 2', fontsize=10, fontweight='bold', family='Arial')

# Remove right and top spines
ax.spines['right'].set_visible(False)
ax.spines['top'].set_visible(False)

# Remove axis ticks and labels
ax.set_xticks([])
ax.set_yticks([])

# Set legend position and style
font_properties = FontProperties(weight='bold')
plt.legend(title=False, bbox_to_anchor=(1.05, 1), loc='upper left', fontsize=10, frameon=False, prop=font_properties, ncol=1)

# Remove grid
plt.grid(False)

# Adjust axis line width
plt.tick_params(axis='both', width=0.5)

# Fix aspect ratio
ax.set_aspect('equal', adjustable='box')

# Adjust layout and save image
plt.tight_layout()
plt.savefig(OUTPUT_PLOT, transparent=True, format='eps')
print(f"Cell population plot saved to {OUTPUT_PLOT}")
plt.show()

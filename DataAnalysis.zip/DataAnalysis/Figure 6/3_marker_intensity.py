import matplotlib

# --- Final fix: Force 'Agg' backend before importing pyplot ---
# This resolves issues on some systems where files are written empty
matplotlib.use('Agg')

import pandas as pd
import matplotlib.pyplot as plt
import os

# --- User Settings ---
# 1. Input Excel file
# Assumed to be in the same directory.
INPUT_FILE = r'tonsils_analyzed.xlsx'

# 2. Output directory for plots
# This will be created in the script's directory.
OUTPUT_DIR = r"marker_intensity_plots"
os.makedirs(OUTPUT_DIR, exist_ok=True)
print(f"--- Plots will be saved to: {OUTPUT_DIR} ---")

# 3. List the exact marker column names to plot
markers_to_plot = [
    'Cell: CD20 mean', 'Nucleus: Ki67 mean', 'Cell: CD68 mean', 'Cell: CD8a mean', 'Cell: CD4 mean', 'Cell: CD34 mean'
]

# --- Data Loading and Processing ---
print(f"\nLoading file: {INPUT_FILE}")
try:
    data = pd.read_excel(INPUT_FILE)
except FileNotFoundError:
    print(f"Error: File not found '{INPUT_FILE}'. Please check the path.")
    exit()

# Extract t-SNE coordinates
tsne_coords = data[['tSNE1', 'tSNE2']]

# --- Extract marker data by exact name ---
missing_markers = [m for m in markers_to_plot if m not in data.columns]
if missing_markers:
    print(f"\nError: The following marker columns were not found in your Excel file: {', '.join(missing_markers)}")
    print(f"Available columns in the file include: {', '.join(data.columns[:15])}...")
    exit()

marker_data = data[markers_to_plot]
print(f"Successfully extracted marker data: {', '.join(marker_data.columns)}")

# --- Loop to generate and save plots ---
cmap = 'Spectral_r'

for idx, marker in enumerate(marker_data.columns, start=1):
    print(f"\n{'=' * 10} Processing marker: {marker} ({idx}/{len(marker_data.columns)}) {'=' * 10}")

    current_column = marker_data[marker]

    # --- 1. Plotting ---
    print("  -> Generating plot...")
    fig, ax = plt.subplots(figsize=(4, 3))
    scatter = plt.scatter(tsne_coords['tSNE1'], tsne_coords['tSNE2'], c=current_column, cmap=cmap, s=5, alpha=0.05)
    plt.colorbar(scatter, label=f'{marker} Intensity')

    # Plot styling...
    plt.title('')
    ax.set_xlabel('')
    ax.set_ylabel('')
    ax.spines['right'].set_visible(False)
    ax.spines['top'].set_visible(False)
    plt.tick_params(axis='both', width=0.5)
    ax.set_xticks([])
    ax.set_yticks([])
    plt.grid(False)
    ax.set_aspect('equal', adjustable='box')
    plt.tight_layout()

    # --- 2. Save and Validate ---
    # !!! Key fix: Remove illegal characters from filename, especially colons ':' !!!
    safe_marker_name = marker.replace(':', '').replace(' ', '_').replace('/', '_')

    # Save SVG
    svg_file_name = f"{idx}_{safe_marker_name}.svg"
    svg_save_path = os.path.join(OUTPUT_DIR, svg_file_name)
    try:
        print(f"  -> Attempting to save SVG to: {svg_save_path}")
        plt.savefig(svg_save_path, transparent=True, format='svg', bbox_inches='tight')

        if os.path.exists(svg_save_path) and os.path.getsize(svg_save_path) > 100:
            print(f"  -> ✅ Success: SVG file saved and is not empty.")
        else:
            print(f"  -> ❌ Fail: SVG file was created but is empty (0KB).")

    except Exception as e:
        print(f"  -> ❌❌❌ Fatal error while saving SVG! Details: {e}")

    # Save PNG
    png_file_name = f"{idx}_{safe_marker_name}.png"
    png_save_path = os.path.join(OUTPUT_DIR, png_file_name)
    try:
        print(f"  -> Attempting to save PNG to: {png_save_path}")
        plt.savefig(png_save_path, transparent=True, format='png', dpi=300, bbox_inches='tight')

        if os.path.exists(png_save_path) and os.path.getsize(png_save_path) > 100:
            print(f"  -> ✅ Success: PNG file saved and is not empty.")
        else:
            print(f"  -> ❌ Fail: PNG file was created but is empty (0KB).")

    except Exception as e:
        print(f"  -> ❌❌❌ Fatal error while saving PNG! Details: {e}")

    plt.close(fig)

print("\n--- All plots processed! ---")
